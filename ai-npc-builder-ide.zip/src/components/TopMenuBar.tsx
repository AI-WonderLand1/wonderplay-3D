import React, { useState, useRef } from 'react';
import {
  Play,
  Pause,
  Square,
  StepForward,
  Layers,
  ChevronDown,
  Sparkles,
  Sliders,
  Settings,
  Minimize2,
  Maximize2,
  X,
  Cpu,
  Monitor,
  FolderTree,
  Share2,
  PanelLeftClose,
  PanelLeftOpen,
  FileUp,
  FileDown,
  UserCheck,
  UserPlus,
  PackagePlus,
  Boxes,
  FileCode,
  Save,
  PlusCircle,
} from 'lucide-react';
import { Logo } from './Logo';

export type AppStudioPage = 'game' | 'movie';

interface TopMenuBarProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStop: () => void;
  selectedAsset: string;
  onSelectAsset: (asset: string) => void;
  isDrawerOpen: boolean;
  onToggleDrawer: () => void;
  activePage: AppStudioPage;
  onSelectPage: (page: AppStudioPage) => void;
  onImportNPC?: (file: File) => void;
  onExportNPC?: () => void;
  onImportAsset?: (file: File) => void;
  onExportAsset?: () => void;
}

export const TopMenuBar: React.FC<TopMenuBarProps> = ({
  isPlaying,
  onTogglePlay,
  onStop,
  selectedAsset,
  onSelectAsset,
  isDrawerOpen,
  onToggleDrawer,
  activePage,
  onSelectPage,
  onImportNPC,
  onExportNPC,
  onImportAsset,
  onExportAsset,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [showAiModal, setShowAiModal] = useState(false);

  // Hidden File Inputs for Import triggers
  const npcFileInputRef = useRef<HTMLInputElement>(null);
  const assetFileInputRef = useRef<HTMLInputElement>(null);

  const handleNpcFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onImportNPC) {
      onImportNPC(file);
    }
    if (e.target) e.target.value = '';
  };

  const handleAssetFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onImportAsset) {
      onImportAsset(file);
    }
    if (e.target) e.target.value = '';
  };

  const menuItems = [
    { label: 'File', isCustom: true },
    { label: 'Edit', items: ['Undo (Ctrl+Z)', 'Redo (Ctrl+Y)', 'Cut', 'Copy', 'Editor Preferences', 'Plugins'] },
    { label: 'Pipeline', items: ['Run Full Reality Capture (COLMAP + Meshroom)', 'Headless Decimation & Cycles Bake', 'Export WonderCanvas .GLB (Draco)', 'Open Batch Photo Dataset...'] },
    { label: 'WonderCanvas', items: ['WonderCanvas Runtime Inspector', 'Draw Call Batching Telemetry', 'VRAM Memory Map', 'Shader WGSL Compilation'] },
    { label: 'View', items: ['Toggle Left Drawer (Ctrl+B)', 'Asset Browser', 'Details Panel', 'Reality Capture Pipeline', 'WonderCanvas Stats', 'AI Behavior Graph', '3D Viewport', 'Movie Sequencer'] },
    { label: 'Build', items: ['Build All Levels / Cine Sequences', 'Build Geometry', 'Build Lighting Only', 'Build Navigation Mesh', 'Compile Behavior Trees'] },
    { label: 'Actor', items: ['Add Character Skeletal Mesh', 'Attach Camera Rig / Track', 'Place AI Controller', 'Add Light Source'] },
    { label: 'AI Tools', items: ['Generate Behavior Tree (Gemini)', 'Auto-Rig Facial Expressions', 'Sync WebRTC Stream', 'Run Neural Dialogue Sim'] },
  ];

  return (
    <div className="h-10 bg-[#141417] border-b border-[#27272a] flex items-center justify-between px-2 text-xs select-none z-50">
      {/* Left: WonderPlay-3D Brand & Main Menu */}
      <div className="flex items-center space-x-1">
        {/* WonderPlay-3D Brand Logo */}
        <div className="flex items-center px-1 py-0.5 rounded hover:bg-zinc-800 transition-colors cursor-pointer">
          <Logo size="sm" showText={true} />
        </div>

        <div className="h-4 w-[1px] bg-zinc-800 mx-0.5" />

        {/* Menu Bar Dropdowns */}
        <div className="flex items-center space-x-0.5 text-zinc-300">
          {/* Hidden File Inputs for Import */}
          <input
            type="file"
            ref={npcFileInputRef}
            onChange={handleNpcFileChange}
            accept=".glb,.gltf,.json,.vrm,.fbx"
            className="hidden"
          />
          <input
            type="file"
            ref={assetFileInputRef}
            onChange={handleAssetFileChange}
            accept=".glb,.gltf,.obj,.fbx,.json,.bin,.zip"
            className="hidden"
          />

          {menuItems.map((menu) => (
            <div key={menu.label} className="relative">
              <button
                onClick={() => setActiveMenu(activeMenu === menu.label ? null : menu.label)}
                className={`px-2 py-1 rounded text-xs transition-colors hover:text-white ${
                  activeMenu === menu.label ? 'bg-zinc-800 text-white' : 'hover:bg-zinc-800/60'
                }`}
              >
                {menu.label}
              </button>

              {activeMenu === menu.label && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setActiveMenu(null)}
                  />
                  {menu.label === 'File' ? (
                    /* DEDICATED FILE MENU WITH SEPARATE NPC & ASSETS IMPORT/EXPORT */
                    <div className="absolute left-0 top-full mt-1 w-64 bg-[#18181b] border border-zinc-700 rounded-lg shadow-2xl py-1 z-50 text-zinc-300 divide-y divide-zinc-800/80 animate-in fade-in-50 zoom-in-95 duration-100 font-sans">
                      {/* Project Basics */}
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setActiveMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <PlusCircle className="w-3.5 h-3.5 text-zinc-400 group-hover:text-white" />
                            <span>New Level / Movie Shot</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 group-hover:text-zinc-200 font-mono">Ctrl+N</span>
                        </button>

                        <button
                          onClick={() => {
                            setActiveMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <Save className="w-3.5 h-3.5 text-zinc-400 group-hover:text-white" />
                            <span>Save Project</span>
                          </div>
                          <span className="text-[10px] text-zinc-500 group-hover:text-zinc-200 font-mono">Ctrl+S</span>
                        </button>
                      </div>

                      {/* NPC CHARACTER IMPORT & EXPORT */}
                      <div className="py-1 bg-sky-950/20">
                        <div className="px-3 py-1 text-[10px] font-mono text-sky-400 font-bold uppercase tracking-wider flex items-center justify-between">
                          <span>NPC Character</span>
                          <span className="text-[9px] bg-sky-900/60 text-sky-300 px-1 py-0.2 rounded border border-sky-700/50">Rig & AI</span>
                        </div>

                        <button
                          onClick={() => {
                            setActiveMenu(null);
                            npcFileInputRef.current?.click();
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <UserPlus className="w-3.5 h-3.5 text-sky-400 group-hover:text-white" />
                            <span className="font-medium text-zinc-200 group-hover:text-white">Import NPC...</span>
                          </div>
                          <span className="text-[10px] text-sky-300/80 group-hover:text-white font-mono">.glb / .json</span>
                        </button>

                        <button
                          onClick={() => {
                            setActiveMenu(null);
                            if (onExportNPC) onExportNPC();
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <FileDown className="w-3.5 h-3.5 text-sky-400 group-hover:text-white" />
                            <span className="font-medium text-zinc-200 group-hover:text-white">Export NPC ({selectedAsset})</span>
                          </div>
                          <span className="text-[10px] text-sky-300/80 group-hover:text-white font-mono">.json</span>
                        </button>
                      </div>

                      {/* SCENE ASSETS & PROPS IMPORT & EXPORT */}
                      <div className="py-1 bg-amber-950/20">
                        <div className="px-3 py-1 text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider flex items-center justify-between">
                          <span>Scene Assets & Props</span>
                          <span className="text-[9px] bg-amber-900/60 text-amber-300 px-1 py-0.2 rounded border border-amber-700/50">3D Models</span>
                        </div>

                        <button
                          onClick={() => {
                            setActiveMenu(null);
                            assetFileInputRef.current?.click();
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-amber-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <PackagePlus className="w-3.5 h-3.5 text-amber-400 group-hover:text-white" />
                            <span className="font-medium text-zinc-200 group-hover:text-white">Import Assets...</span>
                          </div>
                          <span className="text-[10px] text-amber-300/80 group-hover:text-white font-mono">.glb / .obj</span>
                        </button>

                        <button
                          onClick={() => {
                            setActiveMenu(null);
                            if (onExportAsset) onExportAsset();
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-amber-600 hover:text-white text-xs flex items-center justify-between group"
                        >
                          <div className="flex items-center space-x-2">
                            <Boxes className="w-3.5 h-3.5 text-amber-400 group-hover:text-white" />
                            <span className="font-medium text-zinc-200 group-hover:text-white">Export Scene Assets</span>
                          </div>
                          <span className="text-[10px] text-amber-300/80 group-hover:text-white font-mono">.json</span>
                        </button>
                      </div>

                      {/* Project Settings */}
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setActiveMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-zinc-800 text-xs flex items-center space-x-2 text-zinc-400 hover:text-zinc-200"
                        >
                          <Settings className="w-3.5 h-3.5" />
                          <span>Project Settings</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute left-0 top-full mt-1 w-56 bg-[#18181b] border border-zinc-700 rounded shadow-2xl py-1 z-50 text-zinc-300">
                      {menu.items?.map((item, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            if (item.includes('Drawer') || item.includes('Asset') || item.includes('Details') || item.includes('Pipeline') || item.includes('WonderCanvas')) {
                              if (!isDrawerOpen) onToggleDrawer();
                            }
                            setActiveMenu(null);
                          }}
                          className="w-full text-left px-3 py-1.5 hover:bg-sky-600 hover:text-white text-xs flex items-center justify-between"
                        >
                          <span>{item}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Center: Engine Play / Pause / Stop Simulation Controls & Studio Switcher */}
      <div className="flex items-center space-x-3">
        {/* Engine Play / Pause / Stop Controls */}
        <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded p-0.5 space-x-0.5 shadow-inner">
          <button
            onClick={onTogglePlay}
            title={isPlaying ? 'Pause Simulation' : 'Run AI Simulation (Play)'}
            className={`px-2.5 py-1 rounded flex items-center space-x-1 text-xs font-semibold transition-all ${
              isPlaying
                ? 'bg-amber-600/90 text-white shadow-[0_0_10px_rgba(217,119,6,0.5)] animate-pulse'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.3)]'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3 h-3 fill-current" />
                <span className="text-[10px]">PAUSE</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 fill-current" />
                <span className="text-[10px]">PLAY</span>
              </>
            )}
          </button>

          <button
            onClick={onStop}
            title="Stop Simulation"
            className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-rose-400 rounded transition-colors"
          >
            <Square className="w-3 h-3 fill-current" />
          </button>

          <button
            onClick={onTogglePlay}
            title="Step Next Simulation Frame"
            className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-sky-400 rounded transition-colors"
          >
            <StepForward className="w-3 h-3" />
          </button>
        </div>

        {/* Layout indicator */}
        <div className="hidden lg:flex items-center text-zinc-400 bg-zinc-900 border border-zinc-800 rounded px-2 py-1 text-[11px] space-x-1">
          <Layers className="w-3 h-3 text-zinc-400" />
          <span>Layout: Default IDE</span>
        </div>
      </div>

      {/* Right: User Project selector & Window Controls */}
      <div className="flex items-center space-x-2 text-zinc-400">
        {/* User Project Selector on Right Side */}
        <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-2 py-0.5 text-zinc-300 space-x-1.5 shadow-inner">
          <Cpu className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-[11px] text-sky-400 font-mono font-bold">User Project:</span>
          <select
            value={selectedAsset}
            onChange={(e) => onSelectAsset(e.target.value)}
            aria-label="User Project Asset"
            className="bg-transparent text-zinc-100 text-xs font-mono font-semibold focus:outline-none cursor-pointer pr-1"
          >
            <option value="SK_DigitalHuman_01" className="bg-zinc-900 text-zinc-200">SK_DigitalHuman_01</option>
            <option value="SK_Songling_Combat" className="bg-zinc-900 text-zinc-200">SK_Songling_Combat</option>
            <option value="SK_Cyborg_Companion" className="bg-zinc-900 text-zinc-200">SK_Cyborg_Companion</option>
          </select>
        </div>
        <div className="h-4 w-[1px] bg-zinc-800 mx-0.5" />

        {/* Window controls (IDE Mock) */}
        <div className="flex items-center space-x-1">
          <button aria-label="Minimize Window" className="p-1 hover:bg-zinc-800 hover:text-zinc-200 rounded">
            <Minimize2 className="w-3 h-3" />
          </button>
          <button aria-label="Maximize Window" className="p-1 hover:bg-zinc-800 hover:text-zinc-200 rounded">
            <Maximize2 className="w-3 h-3" />
          </button>
          <button aria-label="Close Window" className="p-1 hover:bg-rose-600 hover:text-white rounded">
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* AI Tools Modal */}
      {showAiModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#141417] border border-zinc-700 rounded-lg max-w-md w-full shadow-2xl p-4 text-zinc-300">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center space-x-2">
                <Logo size="sm" showText={false} />
                <h3 className="font-semibold text-white text-sm">WonderPlay-3D Systems</h3>
              </div>
              <button onClick={() => setShowAiModal(false)} aria-label="Close Dialog" className="text-zinc-500 hover:text-zinc-200">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="py-3 space-y-2 text-xs">
              <p className="text-zinc-400">
                WonderPlay-3D integrates high-performance 3D WonderCanvas rendering, real-time AI perception graphs, and neural voice synchronization:
              </p>
              <div className="bg-zinc-900 p-2.5 rounded border border-zinc-800 space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between"><span className="text-zinc-400">Target Rig:</span><span className="text-sky-400">{selectedAsset}</span></div>
                <div className="flex justify-between"><span className="text-zinc-400">WebRTC Audio Bridge:</span><span className="text-emerald-400">Connected (45ms)</span></div>
                <div className="flex justify-between"><span className="text-zinc-400">Renderer Backend:</span><span className="text-amber-400">WonderCanvas PathTracer 16.8ms</span></div>
                <div className="flex justify-between"><span className="text-zinc-400">Behavior State:</span><span className="text-purple-400">Idle -&gt; Perception Active</span></div>
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowAiModal(false)}
                className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded font-medium text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
