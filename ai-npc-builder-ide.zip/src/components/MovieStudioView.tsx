import React, { useState } from 'react';
import {
  Clapperboard,
  Play,
  Pause,
  RotateCcw,
  Camera,
  Film,
  Layers,
  Sparkles,
  Sliders,
  Volume2,
  Video,
  Sun,
  Eye,
  Settings,
  Scissors,
  Plus,
  Tv,
  Clock,
  Radio,
  ChevronRight,
} from 'lucide-react';

interface MovieStudioViewProps {
  selectedAsset: string;
  isPlaying: boolean;
  onTogglePlay: () => void;
}

interface ShotTrack {
  id: string;
  name: string;
  cameraLens: string;
  framing: string;
  startFrame: number;
  endFrame: number;
  color: string;
  dialogue?: string;
}

export const MovieStudioView: React.FC<MovieStudioViewProps> = ({
  selectedAsset,
  isPlaying,
  onTogglePlay,
}) => {
  const [activeShot, setActiveShot] = useState<string>('shot-1');
  const [currentFrame, setCurrentFrame] = useState<number>(48);
  const [totalFrames] = useState<number>(240); // 10s at 24fps
  const [aspectRatio, setAspectRatio] = useState<'2.39:1' | '16:9' | '1.85:1'>('2.39:1');
  const [cameraFocalLength, setCameraFocalLength] = useState<number>(50);
  const [aperture, setAperture] = useState<number>(1.8);
  const [focusDistance, setFocusDistance] = useState<number>(2.4);
  const [colorGrade, setColorGrade] = useState<'TealOrange' | 'Noir' | 'Cyberpunk' | 'Natural'>('TealOrange');

  const shots: ShotTrack[] = [
    {
      id: 'shot-1',
      name: 'Shot 01: Wide Establishing Pan',
      cameraLens: '35mm Anamorphic T1.5',
      framing: 'Full Body Tracking Dolly',
      startFrame: 0,
      endFrame: 72,
      color: '#0284c7',
      dialogue: '[AI System]: Sector 7 initialization confirmed.',
    },
    {
      id: 'shot-2',
      name: 'Shot 02: Medium Close-Up Dialogue',
      cameraLens: '85mm Prime T1.8',
      framing: 'Over-the-Shoulder 45°',
      startFrame: 72,
      endFrame: 160,
      color: '#d97706',
      dialogue: '[Agent 01]: Reconstructing neural telemetry stream now.',
    },
    {
      id: 'shot-3',
      name: 'Shot 03: Dramatic Low Angle Hero',
      cameraLens: '24mm Ultra Wide',
      framing: 'Dutch Angle Pedestal Up',
      startFrame: 160,
      endFrame: 240,
      color: '#9333ea',
      dialogue: '[AI System]: Standby for full matrix convergence.',
    },
  ];

  return (
    <div className="flex-1 flex flex-col bg-[#0b0b0e] text-zinc-200 overflow-hidden font-sans select-none">
      {/* 1. CINEMA DIRECTOR TOP CONTROL BAR */}
      <div className="h-10 bg-[#121216] border-b border-zinc-800 px-3 flex items-center justify-between text-xs font-mono">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 bg-amber-950/70 border border-amber-600/50 px-2 py-0.5 rounded text-amber-300 font-semibold">
            <Clapperboard className="w-3.5 h-3.5" />
            <span>CINEMA DIRECTOR SEQUENCER</span>
          </div>

          <div className="h-4 w-[1px] bg-zinc-800" />

          {/* Aspect Ratio Selector */}
          <div className="flex items-center space-x-1 text-zinc-400">
            <span className="text-[10px]">Aspect:</span>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as any)}
              className="bg-zinc-900 border border-zinc-800 rounded px-1.5 py-0.5 text-zinc-200 text-[11px] focus:outline-none"
            >
              <option value="2.39:1">2.39:1 (Cinemascope Anamorphic)</option>
              <option value="1.85:1">1.85:1 (Flat Theatrical)</option>
              <option value="16:9">16:9 (UHD Broadcast)</option>
            </select>
          </div>

          {/* Color Grade LUT */}
          <div className="flex items-center space-x-1 text-zinc-400">
            <span className="text-[10px]">LUT:</span>
            <select
              value={colorGrade}
              onChange={(e) => setColorGrade(e.target.value as any)}
              className="bg-zinc-900 border border-zinc-800 rounded px-1.5 py-0.5 text-zinc-200 text-[11px] focus:outline-none"
            >
              <option value="TealOrange">Teal & Orange Blockbuster</option>
              <option value="Cyberpunk">Cyberpunk Neon Bleed</option>
              <option value="Noir">High Contrast Neo-Noir</option>
              <option value="Natural">Rec.709 Natural Neutral</option>
            </select>
          </div>
        </div>

        {/* Right Frame Counter / Timecode */}
        <div className="flex items-center space-x-3 text-zinc-400 font-mono text-[11px]">
          <div className="bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800 flex items-center space-x-2">
            <Clock className="w-3 h-3 text-sky-400" />
            <span className="text-white font-bold">
              TC 00:00:{Math.floor(currentFrame / 24).toString().padStart(2, '0')}:{(currentFrame % 24).toString().padStart(2, '0')}
            </span>
            <span className="text-zinc-500">@ 24.00 FPS</span>
          </div>

          <span className="text-zinc-500">Frame: {currentFrame} / {totalFrames}</span>
        </div>
      </div>

      {/* 2. MAIN CINEMATIC STAGE & CAMERA VIEW */}
      <div className="flex-1 flex overflow-hidden">
        {/* Cinema Viewport Canvas */}
        <div className="flex-1 flex flex-col bg-[#070709] relative justify-center items-center p-4 overflow-hidden">
          {/* Aspect Ratio Framing Matte Box */}
          <div
            className={`relative bg-black rounded border border-zinc-800 shadow-[0_0_50px_rgba(0,0,0,0.9)] flex items-center justify-center overflow-hidden transition-all ${
              aspectRatio === '2.39:1'
                ? 'w-full max-w-[860px] aspect-[2.39/1]'
                : aspectRatio === '1.85:1'
                ? 'w-full max-w-[760px] aspect-[1.85/1]'
                : 'w-full max-w-[720px] aspect-[16/9]'
            }`}
          >
            {/* Camera Viewport Overlay UI */}
            <div className="absolute inset-0 pointer-events-none p-3 flex flex-col justify-between z-20">
              {/* Top Viewport Metadata */}
              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400">
                <div className="flex items-center space-x-2 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded border border-zinc-800">
                  <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                  <span className="text-rose-400 font-bold">REC [CAMERA A]</span>
                  <span>{cameraFocalLength}mm f/{aperture}</span>
                </div>

                <div className="bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded border border-zinc-800">
                  <span>ISO 800 • 180.0° Shutter • 5600K</span>
                </div>
              </div>

              {/* Center Crosshairs & Rule-of-Thirds Grid */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-full h-full grid grid-cols-3 grid-rows-3 border border-white/10">
                  <div className="border-r border-b border-white/10" />
                  <div className="border-r border-b border-white/10" />
                  <div className="border-b border-white/10" />
                  <div className="border-r border-b border-white/10" />
                  <div className="border-r border-b border-white/10 flex items-center justify-center">
                    <div className="w-4 h-4 border border-amber-400/40 rounded-full" />
                  </div>
                  <div className="border-b border-white/10" />
                  <div className="border-r border-white/10" />
                  <div className="border-r border-white/10" />
                  <div />
                </div>
              </div>

              {/* Subtitle / Dialogue Live Preview Overlay */}
              <div className="w-full flex justify-center pb-2">
                <div className="bg-black/80 backdrop-blur-sm border border-zinc-700/80 px-4 py-1 rounded text-center max-w-lg">
                  <p className="text-xs text-amber-200 font-sans tracking-wide">
                    {shots.find((s) => s.id === activeShot)?.dialogue || '[Voice Synthesizer Sync Ready]'}
                  </p>
                </div>
              </div>
            </div>

            {/* Simulated 3D Character Film Set Lighting */}
            <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-t from-[#121018] via-[#090a10] to-[#040407]">
              {/* Volumetric Rim Light */}
              <div className={`absolute -top-10 left-1/4 w-96 h-96 rounded-full blur-3xl opacity-30 ${
                colorGrade === 'Cyberpunk' ? 'bg-fuchsia-600' : colorGrade === 'TealOrange' ? 'bg-amber-500' : 'bg-sky-500'
              }`} />
              <div className={`absolute bottom-0 right-1/4 w-80 h-80 rounded-full blur-3xl opacity-25 ${
                colorGrade === 'TealOrange' ? 'bg-cyan-600' : 'bg-indigo-600'
              }`} />

              {/* Character Silhouetted Instance */}
              <div className="relative z-10 flex flex-col items-center">
                <div className="w-32 h-56 relative flex items-center justify-center">
                  <svg viewBox="0 0 100 180" className="w-full h-full filter drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]">
                    {/* Head */}
                    <circle cx="50" cy="25" r="14" fill="#3f3f46" stroke="#f59e0b" strokeWidth="1.5" />
                    {/* Eyes */}
                    <circle cx="45" cy="24" r="2" fill="#38bdf8" />
                    <circle cx="55" cy="24" r="2" fill="#38bdf8" />
                    {/* Torso & Armor */}
                    <path d="M30 45 L70 45 L62 105 L38 105 Z" fill="#27272a" stroke="#71717a" strokeWidth="1.2" />
                    <path d="M42 50 L58 50 L54 85 L46 85 Z" fill="#18181b" stroke="#f59e0b" strokeWidth="1" />
                    {/* Arms */}
                    <line x1="28" y1="48" x2="16" y2="95" stroke="#3f3f46" strokeWidth="6" strokeLinecap="round" />
                    <line x1="72" y1="48" x2="84" y2="95" stroke="#3f3f46" strokeWidth="6" strokeLinecap="round" />
                    {/* Legs */}
                    <line x1="42" y1="108" x2="38" y2="168" stroke="#27272a" strokeWidth="7" strokeLinecap="round" />
                    <line x1="58" y1="108" x2="62" y2="168" stroke="#27272a" strokeWidth="7" strokeLinecap="round" />
                  </svg>
                </div>
                <span className="text-[10px] font-mono text-zinc-500 mt-1">Actor Rig: [{selectedAsset}]</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Camera & Lighting Rig Controls Panel */}
        <div className="w-80 bg-[#121216] border-l border-zinc-800 flex flex-col p-3 space-y-4 text-xs font-sans overflow-y-auto custom-scrollbar">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <span className="font-semibold text-white flex items-center space-x-1.5">
              <Camera className="w-4 h-4 text-amber-400" />
              <span>Virtual Cine Camera</span>
            </span>
            <span className="text-[10px] text-zinc-500 font-mono">ARRI Alexa 65 Sim</span>
          </div>

          {/* Focal Length Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-zinc-300 text-[11px]">
              <span>Focal Length</span>
              <span className="text-amber-400 font-mono font-bold">{cameraFocalLength} mm</span>
            </div>
            <input
              type="range"
              min="18"
              max="135"
              value={cameraFocalLength}
              onChange={(e) => setCameraFocalLength(Number(e.target.value))}
              className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
              <span>18mm (Wide)</span>
              <span>50mm (Normal)</span>
              <span>135mm (Tele)</span>
            </div>
          </div>

          {/* Aperture (Depth of Field) */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-zinc-300 text-[11px]">
              <span>Aperture (f-stop / Bokeh)</span>
              <span className="text-amber-400 font-mono font-bold">f/{aperture}</span>
            </div>
            <input
              type="range"
              min="1.2"
              max="16.0"
              step="0.2"
              value={aperture}
              onChange={(e) => setAperture(Number(e.target.value))}
              className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
              <span>f/1.2 (Shallow DOF)</span>
              <span>f/8.0 (Deep DOF)</span>
            </div>
          </div>

          {/* Focus Distance */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-zinc-300 text-[11px]">
              <span>Focus Plane Distance</span>
              <span className="text-sky-400 font-mono font-bold">{focusDistance} m</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="10.0"
              step="0.1"
              value={focusDistance}
              onChange={(e) => setFocusDistance(Number(e.target.value))}
              className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
            />
          </div>

          {/* Key 3-Point Light Rig */}
          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
              3-Point Cinematic Lighting
            </span>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between bg-zinc-900/80 p-2 rounded border border-zinc-800">
                <div className="flex items-center space-x-2">
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Key Light (Warm 3200K)</span>
                </div>
                <span className="text-amber-400 font-mono text-[11px]">85% • Softbox</span>
              </div>
              <div className="flex items-center justify-between bg-zinc-900/80 p-2 rounded border border-zinc-800">
                <div className="flex items-center space-x-2">
                  <Sun className="w-3.5 h-3.5 text-sky-400" />
                  <span>Fill Light (Cool 6500K)</span>
                </div>
                <span className="text-sky-400 font-mono text-[11px]">30% • Diffused</span>
              </div>
              <div className="flex items-center justify-between bg-zinc-900/80 p-2 rounded border border-zinc-800">
                <div className="flex items-center space-x-2">
                  <Sun className="w-3.5 h-3.5 text-fuchsia-400" />
                  <span>Backlight Rim (Anamorphic)</span>
                </div>
                <span className="text-fuchsia-400 font-mono text-[11px]">100% • Hard Rim</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. MULTI-TRACK NON-LINEAR TIMELINE SEQUENCER (NLE) */}
      <div className="h-48 bg-[#0e0e12] border-t border-zinc-800 flex flex-col p-2 space-y-2 select-none">
        {/* Playback Controls & Frame Scrubber Header */}
        <div className="flex items-center justify-between px-2 text-xs">
          <div className="flex items-center space-x-2">
            <button
              onClick={onTogglePlay}
              className={`p-1.5 rounded flex items-center space-x-1 font-semibold text-xs transition-colors ${
                isPlaying ? 'bg-amber-600 text-white' : 'bg-sky-600 hover:bg-sky-500 text-white'
              }`}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isPlaying ? 'Pause Sequence' : 'Play Timeline'}</span>
            </button>

            <button
              onClick={() => setCurrentFrame(0)}
              className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded"
              title="Return to Frame 0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <div className="h-4 w-[1px] bg-zinc-800 mx-1" />

            <span className="text-zinc-400 font-mono text-[11px]">
              Sequencer Track: 3 Camera Angles • 1 Neural Audio Voice
            </span>
          </div>

          <div className="flex items-center space-x-2 text-zinc-400 text-xs">
            <button className="flex items-center space-x-1 px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-200">
              <Scissors className="w-3 h-3 text-sky-400" />
              <span>Split Shot (C)</span>
            </button>
            <button className="flex items-center space-x-1 px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-200">
              <Plus className="w-3 h-3 text-emerald-400" />
              <span>Add Camera Track</span>
            </button>
          </div>
        </div>

        {/* Timeline Tracks Grid */}
        <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded p-2 flex flex-col space-y-1.5 overflow-hidden">
          {/* Time Ruler */}
          <div className="h-4 border-b border-zinc-800 flex text-[9px] font-mono text-zinc-500 px-20">
            {Array.from({ length: 11 }).map((_, i) => (
              <div key={i} className="flex-1 border-l border-zinc-800 pl-1">
                {i * 24}f ({(i * 1.0).toFixed(0)}s)
              </div>
            ))}
          </div>

          {/* Track 1: Camera Cuts */}
          <div className="flex items-center space-x-2 text-xs">
            <span className="w-18 text-[10px] font-mono text-zinc-400 flex items-center space-x-1 shrink-0">
              <Camera className="w-3 h-3 text-amber-400" />
              <span>Cameras</span>
            </span>

            <div className="flex-1 h-8 bg-zinc-900/90 rounded flex p-0.5 space-x-1 relative">
              {shots.map((shot) => (
                <div
                  key={shot.id}
                  onClick={() => setActiveShot(shot.id)}
                  style={{
                    flexGrow: shot.endFrame - shot.startFrame,
                    borderColor: activeShot === shot.id ? '#f59e0b' : 'transparent',
                  }}
                  className={`h-full rounded px-2 flex items-center justify-between text-[10px] font-mono cursor-pointer border transition-all ${
                    activeShot === shot.id
                      ? 'bg-amber-950/80 text-amber-200 border-amber-500 shadow-sm'
                      : 'bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300'
                  }`}
                >
                  <span className="truncate font-semibold">{shot.name}</span>
                  <span className="text-[9px] text-zinc-400">{shot.cameraLens}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Track 2: Neural Speech & Dialogue Audio */}
          <div className="flex items-center space-x-2 text-xs">
            <span className="w-18 text-[10px] font-mono text-zinc-400 flex items-center space-x-1 shrink-0">
              <Volume2 className="w-3 h-3 text-emerald-400" />
              <span>Dialogue</span>
            </span>

            <div className="flex-1 h-7 bg-zinc-900/90 rounded flex p-0.5 space-x-1">
              <div className="w-2/5 h-full bg-emerald-950/80 border border-emerald-600/50 rounded px-2 flex items-center text-[10px] text-emerald-300 font-mono">
                <span>EN_FEMALE_03: "Sector 7 initialization confirmed."</span>
              </div>
              <div className="w-3/5 h-full bg-emerald-950/80 border border-emerald-600/50 rounded px-2 flex items-center text-[10px] text-emerald-300 font-mono">
                <span>EN_FEMALE_03: "Reconstructing neural telemetry stream now."</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
