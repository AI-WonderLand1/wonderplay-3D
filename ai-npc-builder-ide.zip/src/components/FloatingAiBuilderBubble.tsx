import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Minimize2,
  Maximize2,
  X,
  Send,
  Wand2,
  Gamepad2,
  Clapperboard,
  Layers,
  ChevronDown,
  ChevronUp,
  Cpu,
  Bot,
  Move,
  RefreshCw,
  Sliders,
  Play,
  CheckCircle2,
  Terminal,
} from 'lucide-react';
import { Logo } from './Logo';

interface FloatingAiBuilderBubbleProps {
  onBuildPrompt?: (prompt: string, mode: 'game' | 'movie' | 'asset' | 'shader') => void;
  activeProjectMode?: 'game' | 'movie';
}

export const FloatingAiBuilderBubble: React.FC<FloatingAiBuilderBubbleProps> = ({
  onBuildPrompt,
  activeProjectMode = 'game',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [promptText, setPromptText] = useState('');
  const [buildMode, setBuildMode] = useState<'game' | 'movie' | 'asset' | 'shader'>(
    activeProjectMode === 'movie' ? 'movie' : 'game'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedHistory, setGeneratedHistory] = useState<
    Array<{ id: string; prompt: string; target: string; time: string }>
  >([
    {
      id: 'h1',
      prompt: 'Cyberpunk rainy alleyway cinematic camera track & volumetric lights',
      target: 'Movie Scene Rig',
      time: '2m ago',
    },
    {
      id: 'h2',
      prompt: 'Combat NPC AI state machine with dynamic aggro range and roll dodge',
      target: 'Game AI Controller',
      time: '8m ago',
    },
  ]);

  // Position state for drag
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 24, y: 70 });
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 24,
    posY: 70,
  });

  const handleMouseDown = (e: React.MouseEvent) => {
    // Only drag from header or bubble
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragRef.current.startX;
      const dy = e.clientY - dragRef.current.startY;
      
      const newX = Math.max(10, Math.min(window.innerWidth - 380, dragRef.current.posX + dx));
      const newY = Math.max(10, Math.min(window.innerHeight - 200, dragRef.current.posY + dy));
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const handleExecuteBuild = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!promptText.trim()) return;

    setIsGenerating(true);
    const currentP = promptText;
    const currentM = buildMode;

    setTimeout(() => {
      setIsGenerating(false);
      setGeneratedHistory((prev) => [
        {
          id: `gen-${Date.now()}`,
          prompt: currentP,
          target: currentM === 'movie' ? 'Cinematic Movie Shot' : currentM === 'game' ? 'Game Logic / Level' : 'PBR Shader Graph',
          time: 'Just now',
        },
        ...prev,
      ]);
      setPromptText('');
      onBuildPrompt?.(currentP, currentM);
    }, 1200);
  };

  const presetPrompts = [
    {
      label: '🎬 Cinematic Track & Pan',
      mode: 'movie' as const,
      text: 'Create a 24fps anamorphic camera dolly shot focusing on character with key rim light',
    },
    {
      label: '🎮 Boss Fight State Machine',
      mode: 'game' as const,
      text: 'Generate a 3-phase boss AI behavior tree with melee combo, enrage timer, and telegraph cue',
    },
    {
      label: '🌆 Procedural Cyber Stage',
      mode: 'game' as const,
      text: 'Build an arena level layout with 4 cover barriers, jump pad triggers, and neon point lights',
    },
    {
      label: '🎥 Dialogue Shot-Reverse-Shot',
      mode: 'movie' as const,
      text: 'Setup a 2-character dialogue sequence with audio-driven facial blendshapes and shallow depth of field',
    },
  ];

  return (
    <div
      style={{
        position: 'fixed',
        left: `${position.x}px`,
        top: `${position.y}px`,
        zIndex: 9999,
      }}
      className="select-none font-sans"
    >
      {/* 1. COLLAPSED FLOATING ACTION BUBBLE */}
      {!isOpen && (
        <div
          onMouseDown={handleMouseDown}
          onClick={() => setIsOpen(true)}
          className={`group flex items-center space-x-2 px-3 py-2 bg-gradient-to-r from-zinc-900 via-[#181822] to-zinc-900 border border-sky-500/50 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.7),0_0_15px_rgba(56,189,248,0.25)] hover:shadow-[0_8px_32px_rgba(0,0,0,0.8),0_0_25px_rgba(56,189,248,0.5)] cursor-pointer transition-all hover:scale-105 active:scale-95 text-white backdrop-blur-md`}
        >
          {/* Animated Glowing Ring & Emblem */}
          <div className="relative w-7 h-7 flex items-center justify-center rounded-full bg-sky-500/20 border border-sky-400/60 shadow-inner">
            <Sparkles className="w-4 h-4 text-sky-400 animate-pulse" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
          </div>

          <div className="flex flex-col text-left">
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold font-sans tracking-wide text-zinc-100 group-hover:text-sky-300 transition-colors">
                Alice AI
              </span>
              <span className="text-[9px] px-1 py-0.2 rounded bg-sky-950 text-sky-400 font-mono font-bold border border-sky-800">
                PROMPT
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono">
              Games & Movies • Click to Expand
            </span>
          </div>

          <div className="pl-1 text-zinc-500 group-hover:text-zinc-300">
            <Move className="w-3.5 h-3.5 opacity-60" />
          </div>
        </div>
      )}

      {/* 2. EXPANDED MOVABLE & MINIMIZABLE ALICE AI PANEL */}
      {isOpen && (
        <div className="w-[360px] sm:w-[400px] bg-[#121216]/95 border border-sky-500/40 rounded-xl shadow-[0_20px_60px_rgba(0,0,0,0.85),0_0_30px_rgba(56,189,248,0.2)] backdrop-blur-xl flex flex-col overflow-hidden text-zinc-200 animate-in fade-in zoom-in-95 duration-150">
          {/* Draggable Title Header Bar */}
          <div
            onMouseDown={handleMouseDown}
            className="h-9 px-3 bg-gradient-to-r from-zinc-900 via-[#181824] to-zinc-900 border-b border-zinc-800 flex items-center justify-between cursor-move text-xs font-medium"
          >
            <div className="flex items-center space-x-2">
              <div className="w-5 h-5 rounded-full bg-sky-500/20 border border-sky-400/50 flex items-center justify-center">
                <Wand2 className="w-3 h-3 text-sky-400" />
              </div>
              <span className="font-semibold text-white font-sans text-xs tracking-tight">
                Alice AI — Studio Builder
              </span>
              <span className="text-[9px] text-zinc-400 font-mono bg-zinc-800/80 px-1.5 py-0.5 rounded border border-zinc-700">
                WonderPlay-3D
              </span>
            </div>

            {/* Window Actions */}
            <div className="flex items-center space-x-1 text-zinc-400">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                title={isMinimized ? 'Expand window' : 'Minimize window'}
                className="p-1 hover:text-white hover:bg-zinc-800 rounded transition-colors"
              >
                {isMinimized ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close to floating bubble"
                className="p-1 hover:text-rose-400 hover:bg-rose-950/50 rounded transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Minimized Single-line View */}
          {isMinimized ? (
            <div className="p-2.5 bg-zinc-950/80 flex items-center justify-between text-xs">
              <span className="text-zinc-400 font-mono text-[11px] truncate flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Ready for prompt instructions (Games & Movies)</span>
              </span>
              <button
                onClick={() => setIsMinimized(false)}
                className="px-2 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-[10px] font-medium"
              >
                Open
              </button>
            </div>
          ) : (
            /* Full Expanded Form Layout */
            <div className="p-3 space-y-3 max-h-[500px] overflow-y-auto custom-scrollbar">
              {/* Mode Switcher Tabs (Game vs Movie Studio vs Shaders) */}
              <div className="flex items-center space-x-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-[11px] font-medium">
                <button
                  type="button"
                  onClick={() => setBuildMode('game')}
                  className={`flex-1 py-1 px-2 rounded-md flex items-center justify-center space-x-1.5 transition-all ${
                    buildMode === 'game'
                      ? 'bg-sky-950 text-sky-300 border border-sky-600/60 shadow-sm font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Gamepad2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>Game Mode</span>
                </button>

                <button
                  type="button"
                  onClick={() => setBuildMode('movie')}
                  className={`flex-1 py-1 px-2 rounded-md flex items-center justify-center space-x-1.5 transition-all ${
                    buildMode === 'movie'
                      ? 'bg-amber-950 text-amber-300 border border-amber-600/60 shadow-sm font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Clapperboard className="w-3.5 h-3.5 text-amber-400" />
                  <span>Movie Mode</span>
                </button>

                <button
                  type="button"
                  onClick={() => setBuildMode('shader')}
                  className={`flex-1 py-1 px-2 rounded-md flex items-center justify-center space-x-1.5 transition-all ${
                    buildMode === 'shader'
                      ? 'bg-purple-950 text-purple-300 border border-purple-600/60 shadow-sm font-semibold'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5 text-purple-400" />
                  <span>Shaders</span>
                </button>
              </div>

              {/* Natural Language Prompt Input Area */}
              <form onSubmit={handleExecuteBuild} className="space-y-2">
                <div className="relative">
                  <textarea
                    rows={3}
                    value={promptText}
                    onChange={(e) => setPromptText(e.target.value)}
                    placeholder={
                      buildMode === 'movie'
                        ? 'Describe your movie shot or cinematic scene (e.g., Anamorphic dolly track, dramatic rim lighting, dialogue sync)...'
                        : buildMode === 'game'
                        ? 'Describe your gameplay level, character state machine, or trigger logic...'
                        : 'Describe custom PBR material or WonderCanvas procedural shader...'
                    }
                    className="w-full bg-zinc-950/90 border border-zinc-700/80 focus:border-sky-500 rounded-lg p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:ring-1 focus:ring-sky-500 resize-none font-sans leading-relaxed"
                  />
                  <div className="absolute right-2 bottom-2 text-[10px] text-zinc-500 font-mono">
                    Alice AI
                  </div>
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <div className="text-[10px] text-zinc-400 flex items-center space-x-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>Engine Target: WonderCanvas 3D</span>
                  </div>

                  <button
                    type="submit"
                    disabled={isGenerating || !promptText.trim()}
                    className={`px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 text-xs font-semibold shadow-md transition-all ${
                      isGenerating
                        ? 'bg-sky-900 text-sky-200 cursor-wait'
                        : !promptText.trim()
                        ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white active:scale-95 shadow-sky-900/40'
                    }`}
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        <span>Alice is Generating...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Ask Alice to Build</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* Quick Template Prompts */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                  Quick Starter Templates
                </span>
                <div className="grid grid-cols-1 gap-1">
                  {presetPrompts.map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setBuildMode(preset.mode);
                        setPromptText(preset.text);
                      }}
                      className="text-left p-1.5 rounded bg-zinc-900/80 hover:bg-zinc-800/90 border border-zinc-800/80 hover:border-zinc-700 text-zinc-300 transition-colors text-[11px] flex items-center justify-between group"
                    >
                      <span className="truncate">{preset.label}</span>
                      <span className="text-[9px] text-zinc-500 group-hover:text-sky-400 font-mono">
                        use ➔
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Recent AI Generation History Log */}
              {generatedHistory.length > 0 && (
                <div className="space-y-1 pt-2 border-t border-zinc-800/80">
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider font-mono">
                    Recent AI Generations
                  </span>
                  <div className="space-y-1">
                    {generatedHistory.map((item) => (
                      <div
                        key={item.id}
                        className="bg-zinc-950/60 border border-zinc-800/70 p-2 rounded text-[11px] space-y-0.5"
                      >
                        <div className="flex items-center justify-between text-zinc-400 text-[10px]">
                          <span className="text-sky-400 font-medium font-mono">{item.target}</span>
                          <span>{item.time}</span>
                        </div>
                        <p className="text-zinc-300 line-clamp-1 italic text-[11px]">
                          "{item.prompt}"
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
