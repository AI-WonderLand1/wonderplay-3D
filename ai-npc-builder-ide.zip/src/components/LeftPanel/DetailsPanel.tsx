import React, { useState } from 'react';
import {
  Sliders,
  ChevronDown,
  ChevronRight,
  Lock,
  Settings2,
  RotateCcw,
  Sparkles,
  Maximize2,
  Layers,
  CircleDot,
  Eye,
  FileCode2,
} from 'lucide-react';
import { TransformState, PBRMaterial } from '../../types';

interface DetailsPanelProps {
  selectedAsset: string;
  transform: TransformState;
  onTransformChange: (key: keyof TransformState, value: number) => void;
  materials: PBRMaterial[];
  onMaterialUpdate: (id: string, roughness: number, metallic: number) => void;
}

export const DetailsPanel: React.FC<DetailsPanelProps> = ({
  selectedAsset,
  transform,
  onTransformChange,
  materials,
  onMaterialUpdate,
}) => {
  const [openSections, setOpenSections] = useState<{ [key: string]: boolean }>({
    transform: true,
    pbr: true,
    mesh: true,
    aiRig: false,
  });

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  return (
    <div className="flex flex-col h-full bg-[#141417] border-t border-[#27272a] text-xs">
      {/* Details Header */}
      <div className="px-3 py-2 border-b border-zinc-800 flex items-center justify-between bg-[#111114]">
        <div className="flex items-center space-x-1.5 text-zinc-200 font-semibold tracking-wider">
          <Sliders className="w-3.5 h-3.5 text-zinc-400" />
          <span>DETAILS PANEL</span>
        </div>
        <div className="flex items-center space-x-1.5 text-zinc-400">
          <button aria-label="Lock Asset Details" className="p-1 hover:bg-zinc-800 hover:text-zinc-200 rounded">
            <Lock className="w-3 h-3" />
          </button>
          <button aria-label="Details Settings" className="p-1 hover:bg-zinc-800 hover:text-zinc-200 rounded">
            <Settings2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Selected Entity Banner */}
      <div className="px-3 py-2 bg-[#0d0d10] border-b border-zinc-800/80 flex items-center justify-between">
        <div className="flex items-center space-x-2 truncate">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-mono font-medium text-sky-300 truncate">{selectedAsset}</span>
        </div>
        <span className="text-[10px] bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-400 font-mono">
          SkeletalMesh
        </span>
      </div>

      {/* Accordion Scrollable Area */}
      <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/60 p-2 space-y-2">
        {/* TRANSFORM ACCORDION */}
        <div className="rounded bg-[#18181b]/70 border border-zinc-800 overflow-hidden">
          <button
            onClick={() => toggleSection('transform')}
            className="w-full px-2.5 py-1.5 flex items-center justify-between bg-[#1f1f23] hover:bg-[#27272e] transition-colors text-zinc-200 font-medium"
          >
            <div className="flex items-center space-x-1.5">
              {openSections.transform ? (
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
              )}
              <span className="font-semibold text-xs text-zinc-200">Transform</span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">World Offset</span>
          </button>

          {openSections.transform && (
            <div className="p-2.5 space-y-2 font-mono text-[11px] bg-[#121215]">
              {/* Location (XYZ) */}
              <div className="flex items-center space-x-2">
                <span className="w-16 text-zinc-400 font-sans text-xs">Location</span>
                <div className="grid grid-cols-3 gap-1.5 flex-1">
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-rose-500 font-bold text-[10px] mr-1">X</span>
                    <input
                      type="number"
                      aria-label="Location X"
                      value={transform.posX}
                      onChange={(e) => onTransformChange('posX', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-emerald-500 font-bold text-[10px] mr-1">Y</span>
                    <input
                      type="number"
                      aria-label="Location Y"
                      value={transform.posY}
                      onChange={(e) => onTransformChange('posY', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-sky-500 font-bold text-[10px] mr-1">Z</span>
                    <input
                      type="number"
                      aria-label="Location Z"
                      value={transform.posZ}
                      onChange={(e) => onTransformChange('posZ', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Rotation (XYZ) */}
              <div className="flex items-center space-x-2">
                <span className="w-16 text-zinc-400 font-sans text-xs">Rotation</span>
                <div className="grid grid-cols-3 gap-1.5 flex-1">
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-rose-500 font-bold text-[10px] mr-1">X</span>
                    <input
                      type="number"
                      aria-label="Rotation X"
                      value={transform.rotX}
                      onChange={(e) => onTransformChange('rotX', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-emerald-500 font-bold text-[10px] mr-1">Y</span>
                    <input
                      type="number"
                      aria-label="Rotation Y"
                      value={transform.rotY}
                      onChange={(e) => onTransformChange('rotY', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-sky-500 font-bold text-[10px] mr-1">Z</span>
                    <input
                      type="number"
                      aria-label="Rotation Z"
                      value={transform.rotZ}
                      onChange={(e) => onTransformChange('rotZ', parseFloat(e.target.value) || 0)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Scale (XYZ) */}
              <div className="flex items-center space-x-2">
                <span className="w-16 text-zinc-400 font-sans text-xs">Scale</span>
                <div className="grid grid-cols-3 gap-1.5 flex-1">
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-rose-500 font-bold text-[10px] mr-1">X</span>
                    <input
                      type="number"
                      aria-label="Scale X"
                      step="0.1"
                      value={transform.scaleX}
                      onChange={(e) => onTransformChange('scaleX', parseFloat(e.target.value) || 1)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-emerald-500 font-bold text-[10px] mr-1">Y</span>
                    <input
                      type="number"
                      aria-label="Scale Y"
                      step="0.1"
                      value={transform.scaleY}
                      onChange={(e) => onTransformChange('scaleY', parseFloat(e.target.value) || 1)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                  <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-1.5 py-0.5">
                    <span className="text-sky-500 font-bold text-[10px] mr-1">Z</span>
                    <input
                      type="number"
                      aria-label="Scale Z"
                      step="0.1"
                      value={transform.scaleZ}
                      onChange={(e) => onTransformChange('scaleZ', parseFloat(e.target.value) || 1)}
                      className="w-full bg-transparent text-zinc-200 focus:outline-none text-right font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* CUSTOM PBR / SHADERS ACCORDION */}
        <div className="rounded bg-[#18181b]/70 border border-zinc-800 overflow-hidden">
          <button
            onClick={() => toggleSection('pbr')}
            className="w-full px-2.5 py-1.5 flex items-center justify-between bg-[#1f1f23] hover:bg-[#27272e] transition-colors text-zinc-200 font-medium"
          >
            <div className="flex items-center space-x-1.5">
              {openSections.pbr ? (
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
              )}
              <span className="font-semibold text-xs text-zinc-200">Custom PBR / Shaders</span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">2 Slots</span>
          </button>

          {openSections.pbr && (
            <div className="p-2.5 space-y-3 bg-[#121215]">
              {materials.map((mat) => (
                <div
                  key={mat.id}
                  className="p-2 rounded bg-[#18181b] border border-zinc-800 hover:border-zinc-700 transition-colors space-y-2"
                >
                  <div className="flex items-center space-x-2.5">
                    {/* Spherical Material Ball Preview */}
                    <div
                      className={`w-10 h-10 rounded-full border border-zinc-600/70 shrink-0 cursor-pointer shadow-lg hover:scale-105 transition-transform ${mat.previewClass}`}
                      title={`${mat.name} preview sphere`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-semibold text-zinc-200 truncate font-mono">
                        {mat.name}
                      </div>
                      <div className="text-[10px] text-sky-400 font-mono truncate">
                        {mat.shaderType}
                      </div>
                    </div>
                  </div>

                  {/* Sliders for Roughness & Metallic */}
                  <div className="space-y-1.5 pt-1 text-[11px] font-mono">
                    <div className="flex items-center justify-between">
                      <span className="text-zinc-400 text-[10px]">Roughness:</span>
                      <span className="text-zinc-300 text-[10px] font-semibold">
                        {mat.roughness.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      aria-label={`${mat.name} Roughness`}
                      min="0"
                      max="1"
                      step="0.01"
                      value={mat.roughness}
                      onChange={(e) =>
                        onMaterialUpdate(mat.id, parseFloat(e.target.value), mat.metallic)
                      }
                      className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
                    />

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-zinc-400 text-[10px]">Metallic:</span>
                      <span className="text-zinc-300 text-[10px] font-semibold">
                        {mat.metallic.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      aria-label={`${mat.name} Metallic`}
                      min="0"
                      max="1"
                      step="0.01"
                      value={mat.metallic}
                      onChange={(e) =>
                        onMaterialUpdate(mat.id, mat.roughness, parseFloat(e.target.value))
                      }
                      className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                    />
                  </div>

                  {/* Texture Map Tags */}
                  <div className="grid grid-cols-2 gap-1 text-[10px] font-mono pt-1 text-zinc-400">
                    <div className="bg-[#09090b] p-1 rounded border border-zinc-800/80 truncate">
                      <span className="text-zinc-500">Alb:</span> {mat.albedoMap}
                    </div>
                    <div className="bg-[#09090b] p-1 rounded border border-zinc-800/80 truncate">
                      <span className="text-zinc-500">Nrm:</span> {mat.normalMap}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* MESH & SKELETAL RIG ACCORDION */}
        <div className="rounded bg-[#18181b]/70 border border-zinc-800 overflow-hidden">
          <button
            onClick={() => toggleSection('mesh')}
            className="w-full px-2.5 py-1.5 flex items-center justify-between bg-[#1f1f23] hover:bg-[#27272e] transition-colors text-zinc-200 font-medium"
          >
            <div className="flex items-center space-x-1.5">
              {openSections.mesh ? (
                <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-zinc-400" />
              )}
              <span className="font-semibold text-xs text-zinc-200">Mesh & Skeletal Bindings</span>
            </div>
          </button>

          {openSections.mesh && (
            <div className="p-2.5 space-y-2 text-[11px] font-mono bg-[#121215]">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Mesh Binder:</span>
                <span className="text-sky-300 font-semibold">SK_DigitalHuman_LOD0</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Polycount:</span>
                <span className="text-zinc-200">84,320 tris</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">AI Shared Rig:</span>
                <input
                  type="checkbox"
                  aria-label="Enable AI Shared Rig"
                  defaultChecked
                  className="rounded bg-zinc-900 border-zinc-700 text-sky-500 focus:ring-0"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Morph Targets:</span>
                <span className="text-emerald-400">52 ARKit Blends</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
