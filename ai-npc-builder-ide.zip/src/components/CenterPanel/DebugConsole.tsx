import React, { useState } from 'react';
import {
  Terminal,
  Trash2,
  ChevronDown,
  CornerDownLeft,
  Copy,
  Check,
  Footprints,
  Wind,
  Flame,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { ConsoleLogEntry } from '../../types';
import { NpcMotionPreset } from './FullBodyNpcAvatar';

interface DebugConsoleProps {
  logs: ConsoleLogEntry[];
  onClearLogs: () => void;
  onAddLog: (level: ConsoleLogEntry['level'], message: string) => void;
  isOpen?: boolean;
  onToggleOpen?: () => void;
  motionPreset?: NpcMotionPreset;
  onSelectMotionPreset?: (preset: NpcMotionPreset) => void;
  playbackSpeed?: number;
  onSelectPlaybackSpeed?: (speed: number) => void;
}

export const DebugConsole: React.FC<DebugConsoleProps> = ({
  logs,
  onClearLogs,
  onAddLog,
  isOpen = true,
  onToggleOpen,
  motionPreset = 'walk-in-place',
  onSelectMotionPreset,
  playbackSpeed = 1.0,
  onSelectPlaybackSpeed,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [activeTab, setActiveTab] = useState<'console' | 'output' | 'neural' | 'webrtc'>('console');
  const [copied, setCopied] = useState(false);

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;

    const cmd = commandInput.trim();
    onAddLog('INFO', `Cmd Executed: ${cmd}`);

    if (cmd.startsWith('/npc state')) {
      onAddLog('DECISION', `NPC State transitioning to -> ${cmd.split(' ')[2] || 'IDLE'}`);
    } else if (cmd.startsWith('/webrtc ping')) {
      onAddLog('WEBRTC', `WebRTC Ping Round-trip: 42.1ms (Zero Packet Loss)`);
    } else if (cmd.startsWith('/shader recompile')) {
      onAddLog('SHADERS', `PBR Nanoweave Material recompiled successfully in 11.4ms`);
    } else {
      onAddLog('DEBUG', `Engine Response: Command '${cmd}' dispatched to AI Controller.`);
    }

    setCommandInput('');
  };

  const handleCopyLogs = () => {
    const text = logs.map((l) => `[${l.timestamp}] [${l.level}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getLevelColor = (level: ConsoleLogEntry['level']) => {
    switch (level) {
      case 'SUCCESS':
        return 'text-emerald-300 font-bold';
      case 'ERROR':
        return 'text-rose-500 font-bold';
      case 'INFO':
        return 'text-emerald-400 font-bold';
      case 'WARN':
        return 'text-amber-400 font-bold';
      case 'NEURAL':
        return 'text-purple-400 font-bold';
      case 'WEBRTC':
        return 'text-sky-400 font-bold';
      case 'DECISION':
        return 'text-rose-400 font-bold';
      case 'SHADERS':
        return 'text-yellow-400 font-bold';
      case 'AUDIO':
        return 'text-teal-400 font-bold';
      default:
        return 'text-zinc-400 font-bold';
    }
  };

  const filteredLogs = logs.filter((log) => {
    if (activeTab === 'neural') return log.level === 'NEURAL' || log.level === 'DECISION';
    if (activeTab === 'webrtc') return log.level === 'WEBRTC' || log.level === 'AUDIO';
    return true;
  });

  return (
    <div className="h-full bg-[#0a0a0d] border-t border-[#27272a] flex flex-col font-mono select-text shadow-2xl">
      {/* Console Drawer Tab & Action Bar */}
      <div className="h-8 bg-[#141417] border-b border-zinc-800 px-3 flex items-center justify-between text-xs text-zinc-400">
        <div className="flex items-center space-x-1.5 overflow-x-auto py-0.5 no-scrollbar">
          {/* Drawer Title Badge */}
          <div className="flex items-center space-x-1.5 text-zinc-200 font-bold text-[11px] mr-1 shrink-0">
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>DEBUG CONSOLE</span>
          </div>

          {/* Log Category Filter Tabs */}
          <button
            onClick={() => setActiveTab('console')}
            className={`px-2 py-0.5 rounded text-[10px] shrink-0 transition-colors ${
              activeTab === 'console' ? 'bg-zinc-800 text-white font-semibold' : 'hover:bg-zinc-800/60 text-zinc-400'
            }`}
          >
            All Logs ({logs.length})
          </button>
          <button
            onClick={() => setActiveTab('neural')}
            className={`px-2 py-0.5 rounded text-[10px] shrink-0 transition-colors ${
              activeTab === 'neural' ? 'bg-zinc-800 text-purple-300 font-semibold' : 'hover:bg-zinc-800/60 text-zinc-400'
            }`}
          >
            Neural Decisions
          </button>
          <button
            onClick={() => setActiveTab('webrtc')}
            className={`px-2 py-0.5 rounded text-[10px] shrink-0 transition-colors ${
              activeTab === 'webrtc' ? 'bg-zinc-800 text-sky-300 font-semibold' : 'hover:bg-zinc-800/60 text-zinc-400'
            }`}
          >
            WebRTC Stream
          </button>

          <div className="h-3.5 w-[1px] bg-zinc-800 mx-1 shrink-0" />

          {/* MOTION PRESETS (Step In-Place, Idle Breathe, Combat Stance, Dialogue Gestures) */}
          <div className="flex items-center space-x-1 shrink-0">
            <button
              onClick={() => onSelectMotionPreset?.('walk-in-place')}
              title="Step In-Place Motion"
              className={`px-2 py-0.5 rounded text-[10px] flex items-center space-x-1 transition-all ${
                motionPreset === 'walk-in-place'
                  ? 'bg-sky-600 text-white font-bold shadow-xs'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800'
              }`}
            >
              <Footprints className="w-2.5 h-2.5" />
              <span>Step In-Place</span>
            </button>

            <button
              onClick={() => onSelectMotionPreset?.('idle')}
              title="Idle Breathe Motion"
              className={`px-2 py-0.5 rounded text-[10px] flex items-center space-x-1 transition-all ${
                motionPreset === 'idle'
                  ? 'bg-amber-600 text-white font-bold shadow-xs'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800'
              }`}
            >
              <Wind className="w-2.5 h-2.5" />
              <span>Idle Breathe</span>
            </button>

            <button
              onClick={() => onSelectMotionPreset?.('combat')}
              title="Combat Stance Motion"
              className={`px-2 py-0.5 rounded text-[10px] flex items-center space-x-1 transition-all ${
                motionPreset === 'combat'
                  ? 'bg-rose-600 text-white font-bold shadow-xs'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800'
              }`}
            >
              <Flame className="w-2.5 h-2.5" />
              <span>Combat Stance</span>
            </button>

            <button
              onClick={() => onSelectMotionPreset?.('dialogue')}
              title="Dialogue Gestures Motion"
              className={`px-2 py-0.5 rounded text-[10px] flex items-center space-x-1 transition-all ${
                motionPreset === 'dialogue'
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800'
              }`}
            >
              <MessageSquare className="w-2.5 h-2.5" />
              <span>Dialogue Gestures</span>
            </button>
          </div>

          <div className="h-3.5 w-[1px] bg-zinc-800 mx-1 shrink-0" />

          {/* SPEED MULTIPLIER BUTTONS: 0.5x, 1x, 1.5x, 2x */}
          <div className="flex items-center space-x-0.5 bg-zinc-900/90 border border-zinc-800 rounded px-1.5 py-0.5 shrink-0 text-[10px]">
            <span className="text-zinc-500 mr-1 font-mono">Speed:</span>
            {[0.5, 1.0, 1.5, 2.0].map((spd) => (
              <button
                key={spd}
                onClick={() => onSelectPlaybackSpeed?.(spd)}
                className={`px-1.5 py-0.2 rounded font-mono transition-colors ${
                  playbackSpeed === spd
                    ? 'bg-sky-600 text-white font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {spd === 1.0 ? '1x' : `${spd}x`}
              </button>
            ))}
          </div>
        </div>

        {/* Console Action Controls & Drawer Close */}
        <div className="flex items-center space-x-1 shrink-0 ml-2">
          <button
            onClick={handleCopyLogs}
            title="Copy Console Output"
            className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 rounded flex items-center space-x-1 text-[10px]"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
          </button>
          <button
            onClick={onClearLogs}
            title="Clear Console Output"
            className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-rose-400 rounded"
          >
            <Trash2 className="w-3 h-3" />
          </button>
          {onToggleOpen && (
            <button
              onClick={onToggleOpen}
              title="Close Debug Console Drawer"
              className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded ml-1"
            >
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Log Output Stream */}
      <div className="flex-1 overflow-y-auto p-2 text-[10px] leading-relaxed space-y-0.5 bg-[#09090c]">
        {filteredLogs.map((log) => (
          <div key={log.id} className="flex items-start space-x-2 text-zinc-300 hover:bg-zinc-900/60 py-0.5 px-1 rounded">
            <span className="text-zinc-500 shrink-0">[{log.timestamp}]</span>
            <span className={`shrink-0 ${getLevelColor(log.level)}`}>[{log.level}]</span>
            <span className="text-zinc-200 break-all">{log.message}</span>
          </div>
        ))}
      </div>

      {/* Interactive Command Input Bar */}
      <form
        onSubmit={handleCommandSubmit}
        className="h-7 bg-[#111115] border-t border-zinc-800/80 px-2 flex items-center space-x-2 text-xs shrink-0"
      >
        <span className="text-emerald-500 font-bold text-[11px]">Cmd:</span>
        <input
          type="text"
          value={commandInput}
          onChange={(e) => setCommandInput(e.target.value)}
          placeholder="/npc state idle | /webrtc ping | /shader recompile..."
          className="flex-1 bg-transparent text-zinc-100 text-[11px] focus:outline-none placeholder:text-zinc-600 font-mono"
        />
        <button
          type="submit"
          aria-label="Execute Command"
          className="px-2 py-0.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[10px] font-sans flex items-center space-x-1"
        >
          <span>Exec</span>
          <CornerDownLeft className="w-2.5 h-2.5" />
        </button>
      </form>
    </div>
  );
};
