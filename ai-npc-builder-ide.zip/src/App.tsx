import React, { useState, useEffect } from 'react';
import { TopMenuBar, AppStudioPage } from './components/TopMenuBar';
import { LeftDrawer } from './components/LeftDrawer';
import { Viewport3D } from './components/CenterPanel/Viewport3D';
import { DebugConsole } from './components/CenterPanel/DebugConsole';
import { BehaviorGraphEditor } from './components/RightPanel/BehaviorGraphEditor';
import { FooterStatusBar } from './components/FooterStatusBar';
import { BottomQuickAssetsDrawer } from './components/BottomDrawer/BottomQuickAssetsDrawer';
import { MovieStudioView } from './components/MovieStudioView';
import { FloatingAiBuilderBubble } from './components/FloatingAiBuilderBubble';
import {
  initialAssetTree,
  initialTransform,
  initialPBRMaterials,
  initialBehaviorNodes,
  initialConnections,
  initialConsoleLogs,
} from './data/mockData';
import {
  TransformState,
  PBRMaterial,
  BehaviorNode,
  GraphConnection,
  ConsoleLogEntry,
  TreeItem,
  SceneSpawnedObject,
  QuickActionAsset,
} from './types';
import { NpcMotionPreset } from './components/CenterPanel/FullBodyNpcAvatar';
import { ContextMenu } from './components/ContextMenu';

export default function App() {
  // Engine Global State
  const [activePage, setActivePage] = useState<AppStudioPage>('game');
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<string>('SK_DigitalHuman_01');
  const [assetTree, setAssetTree] = useState<TreeItem[]>(initialAssetTree);
  const [transform, setTransform] = useState<TransformState>(initialTransform);
  const [materials, setMaterials] = useState<PBRMaterial[]>(initialPBRMaterials);
  const [behaviorNodes, setBehaviorNodes] = useState<BehaviorNode[]>(initialBehaviorNodes);
  const [connections, setConnections] = useState<GraphConnection[]>(initialConnections);
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLogEntry[]>(initialConsoleLogs);

  // Right-Click Context Menu State
  const [contextMenu, setContextMenu] = useState<{ isOpen: boolean; x: number; y: number }>({
    isOpen: false,
    x: 0,
    y: 0,
  });

  // Left Drawer States
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isDrawerPinned, setIsDrawerPinned] = useState(true);

  // Bottom Quick Action Assets Drawer State
  const [isQuickAssetsDrawerOpen, setIsQuickAssetsDrawerOpen] = useState(false);

  // Bottom Debug Console Drawer State
  const [isDebugConsoleOpen, setIsDebugConsoleOpen] = useState(false);

  // Motion Preset & Playback Speed (Shared Engine State)
  const [motionPreset, setMotionPreset] = useState<NpcMotionPreset>('walk-in-place');
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  // Scene Spawned Objects (Props, Boxes, Rocks, Vehicles, Trees)
  const [spawnedObjects, setSpawnedObjects] = useState<SceneSpawnedObject[]>([
    {
      id: 'init_box_1',
      name: 'Wooden Crate',
      category: 'prop',
      icon: '📦',
      posX: -140,
      posY: 30,
      scale: 1,
      rotation: 12,
      color: '#d97706',
      polyCount: '1.2k tris',
    },
    {
      id: 'init_rock_1',
      name: 'Granite Rock',
      category: 'prop',
      icon: '🪨',
      posX: 160,
      posY: 40,
      scale: 1.2,
      rotation: -25,
      color: '#71717a',
      polyCount: '3.6k tris',
    },
    {
      id: 'init_tree_1',
      name: 'Pine Tree',
      category: 'foliage',
      icon: '🌲',
      posX: -220,
      posY: -40,
      scale: 1.4,
      rotation: 0,
      color: '#16a34a',
      polyCount: '8.2k tris',
    },
  ]);
  const [selectedSpawnedId, setSelectedSpawnedId] = useState<string | null>(null);

  // Comprehensive Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isInputActive =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          (activeEl as HTMLElement).isContentEditable);

      // --- 1. Global Modifier Shortcuts (Work everywhere unless explicitly conflicting) ---
      
      // Ctrl+B / Cmd+B: Toggle Left Drawer
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        setIsDrawerOpen((prev) => !prev);
        return;
      }

      // Alt+A or Ctrl+Q: Toggle Quick Assets & Props Drawer
      if ((e.altKey && e.key.toLowerCase() === 'a') || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'q')) {
        e.preventDefault();
        setIsQuickAssetsDrawerOpen((prev) => !prev);
        return;
      }

      // Ctrl+` or Ctrl+J or Alt+D: Toggle Debug Console Drawer
      if (
        ((e.ctrlKey || e.metaKey) && (e.key === '`' || e.key === '~' || e.key.toLowerCase() === 'j')) ||
        (e.altKey && e.key.toLowerCase() === 'd')
      ) {
        e.preventDefault();
        setIsDebugConsoleOpen((prev) => !prev);
        return;
      }

      // Ctrl+S / Cmd+S: Save Project
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        addConsoleLog('SUCCESS', `Project saved successfully! Active scene: ${selectedAsset}, ${spawnedObjects.length} props.`);
        return;
      }

      // Ctrl+Shift+E: Export NPC Package
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        handleExportNPC();
        return;
      }

      // Ctrl+E: Export Scene Assets Manifest
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 'e') {
        e.preventDefault();
        handleExportAsset();
        return;
      }

      // --- 2. Non-Input Shortcuts (Only when NOT typing into inputs/textareas) ---
      if (isInputActive) return;

      // Spacebar: Play / Pause Simulation
      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((prev) => {
          const next = !prev;
          addConsoleLog('INFO', next ? 'Engine simulation resumed (60 FPS)' : 'Engine simulation paused');
          return next;
        });
        return;
      }

      // Tab: Switch Studio Workspace (Game Studio <-> Cinematic Movie Studio)
      if (e.key === 'Tab' && !e.ctrlKey && !e.altKey && !e.metaKey) {
        e.preventDefault();
        setActivePage((prev) => {
          const next = prev === 'game' ? 'movie' : 'game';
          addConsoleLog('INFO', `Switched workspace mode: ${next === 'movie' ? 'Cinematic Movie Studio' : 'Interactive Game Studio'}`);
          return next;
        });
        return;
      }

      // Number keys 1-4: Switch NPC Motion Presets
      if (e.key === '1') {
        e.preventDefault();
        setMotionPreset('walk-in-place');
        addConsoleLog('INFO', 'Motion preset: Step In-Place');
        return;
      }
      if (e.key === '2') {
        e.preventDefault();
        setMotionPreset('idle');
        addConsoleLog('INFO', 'Motion preset: Idle Breathe');
        return;
      }
      if (e.key === '3') {
        e.preventDefault();
        setMotionPreset('combat');
        addConsoleLog('INFO', 'Motion preset: Combat Stance');
        return;
      }
      if (e.key === '4') {
        e.preventDefault();
        setMotionPreset('dialogue');
        addConsoleLog('INFO', 'Motion preset: Dialogue Gestures');
        return;
      }

      // [ and ]: Playback speed adjustment
      const speeds = [0.5, 1.0, 1.5, 2.0];
      if (e.key === '[') {
        e.preventDefault();
        setPlaybackSpeed((current) => {
          const idx = speeds.indexOf(current);
          const nextSpd = idx > 0 ? speeds[idx - 1] : speeds[0];
          addConsoleLog('INFO', `Playback speed: ${nextSpd}x`);
          return nextSpd;
        });
        return;
      }
      if (e.key === ']') {
        e.preventDefault();
        setPlaybackSpeed((current) => {
          const idx = speeds.indexOf(current);
          const nextSpd = idx < speeds.length - 1 ? speeds[idx + 1] : speeds[speeds.length - 1];
          addConsoleLog('INFO', `Playback speed: ${nextSpd}x`);
          return nextSpd;
        });
        return;
      }

      // Delete / Backspace: Delete selected scene prop
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedSpawnedId) {
        e.preventDefault();
        const obj = spawnedObjects.find((o) => o.id === selectedSpawnedId);
        handleDeleteSpawnedObject(selectedSpawnedId);
        addConsoleLog('INFO', `Removed scene prop [${obj?.name || selectedSpawnedId}]`);
        return;
      }

      // Escape: Deselect object or close drawers
      if (e.key === 'Escape') {
        if (selectedSpawnedId) {
          setSelectedSpawnedId(null);
        } else if (isQuickAssetsDrawerOpen) {
          setIsQuickAssetsDrawerOpen(false);
        } else if (isDebugConsoleOpen) {
          setIsDebugConsoleOpen(false);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    selectedAsset,
    spawnedObjects,
    selectedSpawnedId,
    motionPreset,
    playbackSpeed,
    transform,
    materials,
    behaviorNodes,
    connections,
    assetTree,
    isQuickAssetsDrawerOpen,
    isDebugConsoleOpen,
  ]);

  // Simulation tick when isPlaying is true
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      const timestamp = new Date().toTimeString().split(' ')[0] + '.' + Math.floor(Math.random() * 900 + 100);
      const simulatedDecisions: { level: ConsoleLogEntry['level']; message: string; source: string }[] = [
        { level: 'DECISION', message: 'Perception tick: Target focused in FOV (confidence: 0.96)', source: 'AI Perception' },
        { level: 'NEURAL', message: 'State: Idle -> Trigger random greeting monologue (Voice ID: EN_FEMALE_03)', source: 'BT_Dialogue' },
        { level: 'AUDIO', message: 'WebRTC Audio: Synthesizing response stream | chunk_size: 4096B', source: 'WebRTC Core' },
        { level: 'DEBUG', message: 'ARKit Face Rig: Blend shape weight (Smile: 0.82, BrowRaise: 0.15)', source: 'MorphEngine' },
        { level: 'SHADERS', message: 'Subsurface scattering buffer refreshed in 1.4ms', source: 'PBR Shaders' },
      ];

      const chosen = simulatedDecisions[Math.floor(Math.random() * simulatedDecisions.length)];
      const newEntry: ConsoleLogEntry = {
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp,
        level: chosen.level,
        message: chosen.message,
        nodeSource: chosen.source,
      };

      setConsoleLogs((prev) => [newEntry, ...prev.slice(0, 40)]);
    }, 2800);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Asset Tree Handlers
  const handleToggleFolder = (folderId: string) => {
    const toggleInTree = (items: TreeItem[]): TreeItem[] => {
      return items.map((item) => {
        if (item.id === folderId) {
          return { ...item, isOpen: !item.isOpen };
        }
        if (item.children) {
          return { ...item, children: toggleInTree(item.children) };
        }
        return item;
      });
    };
    setAssetTree(toggleInTree(assetTree));
  };

  const handleSelectAssetItem = (id: string, name: string) => {
    setSelectedAsset(name);
    addConsoleLog('INFO', `Selected asset loaded into active inspector: ${name}`);
  };

  // Transform Handlers
  const handleTransformChange = (key: keyof TransformState, value: number) => {
    setTransform((prev) => ({ ...prev, [key]: value }));
  };

  // Material Handlers
  const handleMaterialUpdate = (id: string, roughness: number, metallic: number) => {
    setMaterials((prev) =>
      prev.map((m) => (m.id === id ? { ...m, roughness, metallic } : m))
    );
  };

  // Behavior Graph Handlers
  const handleNodeMove = (nodeId: string, deltaX: number, deltaY: number) => {
    setBehaviorNodes((prev) =>
      prev.map((node) =>
        node.id === nodeId
          ? { ...node, x: Math.round(node.x + deltaX), y: Math.round(node.y + deltaY) }
          : node
      )
    );
  };

  const handleAddNode = (title: string, category: string) => {
    const newNodeId = `node-${Date.now()}`;
    const headerColor =
      category === 'neural'
        ? 'bg-sky-950/80 border-sky-600 text-sky-200'
        : category === 'audio'
        ? 'bg-emerald-950/80 border-emerald-600 text-emerald-200'
        : 'bg-amber-950/80 border-amber-600 text-amber-200';

    const newNode: BehaviorNode = {
      id: newNodeId,
      title,
      subTitle: `Module: ${category.toUpperCase()}`,
      headerColor,
      x: 350 + (Math.random() * 40 - 20),
      y: 220 + (Math.random() * 40 - 20),
      width: 210,
      inputs: [
        { id: `pin-${newNodeId}-in`, label: 'Execute', type: 'exec', color: '#ffffff' },
        { id: `pin-${newNodeId}-val`, label: 'Context', type: 'string', color: '#38bdf8' },
      ],
      outputs: [
        { id: `pin-${newNodeId}-out`, label: 'Completed', type: 'exec', color: '#ffffff' },
      ],
      isActive: true,
    };

    setBehaviorNodes((prev) => [...prev, newNode]);
    addConsoleLog('DEBUG', `Added behavior node '${title}' to active graph`);
  };

  // Debug Console Log Helpers
  const addConsoleLog = (level: ConsoleLogEntry['level'], message: string) => {
    const timestamp = new Date().toTimeString().split(' ')[0] + '.' + Math.floor(Math.random() * 900 + 100);
    setConsoleLogs((prev) => [
      {
        id: `log-${Date.now()}-${Math.random()}`,
        timestamp,
        level,
        message,
      },
      ...prev.slice(0, 40),
    ]);
  };

  const handleClearLogs = () => {
    setConsoleLogs([]);
  };

  // Quick Spawn and Scene Prop Management Handlers
  const handleSpawnAsset = (asset: QuickActionAsset) => {
    const offset = (spawnedObjects.length % 5) * 35 - 70;
    const newSpawn: SceneSpawnedObject = {
      id: `spawn_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      name: asset.name,
      category: asset.category,
      icon: asset.icon,
      posX: offset,
      posY: 40 + (spawnedObjects.length % 3) * 15,
      scale: asset.defaultScale || 1,
      rotation: Math.floor(Math.random() * 40) - 20,
      color: asset.color,
      polyCount: asset.polyCount,
    };
    setSpawnedObjects((prev) => [...prev, newSpawn]);
    setSelectedSpawnedId(newSpawn.id);
    addConsoleLog('INFO', `Spawned prop [${asset.name}] to 3D scene stage`);
  };

  const handleAddSpawnedObject = (object: SceneSpawnedObject) => {
    setSpawnedObjects((prev) => [...prev, object]);
    setSelectedSpawnedId(object.id);
  };

  const handleDeleteSpawnedObject = (id: string) => {
    setSpawnedObjects((prev) => prev.filter((item) => item.id !== id));
    if (selectedSpawnedId === id) setSelectedSpawnedId(null);
  };

  const handleClearAllSpawned = () => {
    setSpawnedObjects([]);
    setSelectedSpawnedId(null);
    addConsoleLog('INFO', 'Cleared all spawned props from scene');
  };

  // NPC Import & Export Handlers
  const handleImportNPC = (file: File) => {
    const rawName = file.name.replace(/\.[^/.]+$/, '');
    const cleanName = rawName.startsWith('SK_') ? rawName : `SK_${rawName.replace(/\s+/g, '_')}`;

    // Add to assetTree under Characters folder
    setAssetTree((prev) =>
      prev.map((item) => {
        if (item.id === 'folder-characters' && item.children) {
          const exists = item.children.some((c) => c.name === cleanName);
          if (!exists) {
            return {
              ...item,
              children: [
                ...item.children,
                { id: `char-${Date.now()}`, name: cleanName, type: 'character' },
              ],
            };
          }
        }
        return item;
      })
    );

    setSelectedAsset(cleanName);
    addConsoleLog('SUCCESS', `Imported NPC Character [${cleanName}] (${(file.size / 1024).toFixed(1)} KB). Rig bindings & AI ready.`);
  };

  const handleExportNPC = () => {
    const npcData = {
      format: 'WonderPlay-3D NPC Package',
      version: '2.4.0',
      characterName: selectedAsset,
      exportedAt: new Date().toISOString(),
      rigMetadata: {
        meshFormat: 'GLTF 2.0 / Draco Compressed',
        skeleton: 'FullBody_Humanoid_52BlendShapes',
        arkitFaceBlendshapes: true,
        motionPreset,
        playbackSpeed,
      },
      transform,
      materials,
      behaviorGraph: {
        nodes: behaviorNodes,
        connections,
      },
    };

    const blob = new Blob([JSON.stringify(npcData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedAsset}_NPC_Package.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    addConsoleLog('SUCCESS', `Exported NPC Character package for '${selectedAsset}' (${(blob.size / 1024).toFixed(1)} KB).`);
  };

  // Asset Import & Export Handlers
  const handleImportAsset = (file: File) => {
    const rawName = file.name.replace(/\.[^/.]+$/, '');
    const cleanName = rawName.replace(/_/g, ' ');

    // Spawn as a new scene prop
    const colors = ['#0284c7', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#64748b'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const offset = (spawnedObjects.length % 5) * 35 - 70;

    const newSpawn: SceneSpawnedObject = {
      id: `imported_asset_${Date.now()}`,
      name: cleanName,
      category: 'prop',
      icon: '📦',
      posX: offset,
      posY: 30 + (spawnedObjects.length % 4) * 12,
      scale: 1.0,
      rotation: 0,
      color: randomColor,
      polyCount: `${(Math.random() * 8 + 1).toFixed(1)}k tris`,
    };

    setSpawnedObjects((prev) => [...prev, newSpawn]);
    setSelectedSpawnedId(newSpawn.id);

    addConsoleLog('SUCCESS', `Imported Scene Asset [${file.name}] (${(file.size / 1024).toFixed(1)} KB). Placed in 3D stage.`);
  };

  const handleExportAsset = () => {
    const sceneAssetsData = {
      format: 'WonderPlay-3D Scene & Asset Manifest',
      version: '2.4.0',
      exportedAt: new Date().toISOString(),
      activeCharacter: selectedAsset,
      spawnedSceneProps: spawnedObjects,
      assetTreeHierarchy: assetTree,
      pbrMaterials: materials,
      renderPipeline: {
        engine: 'WonderCanvas PathTracer 3D',
        targetGLB: `${selectedAsset}.glb`,
        bakedResolution: '4096x4096',
        dracoCompression: true,
      },
    };

    const blob = new Blob([JSON.stringify(sceneAssetsData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `WonderPlay_Scene_Assets_Manifest.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    addConsoleLog('SUCCESS', `Exported Scene Assets manifest (${spawnedObjects.length} scene props, materials & hierarchy).`);
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({
      isOpen: true,
      x: e.clientX,
      y: e.clientY,
    });
  };

  return (
    <div
      onContextMenu={handleContextMenu}
      className="h-screen w-screen bg-[#09090b] text-[#d4d4d8] flex flex-col overflow-hidden font-sans select-none relative"
    >
      {/* 1. TOP ENGINE MENU & SIMULATION CONTROLS */}
      <TopMenuBar
        isPlaying={isPlaying}
        onTogglePlay={() => {
          setIsPlaying(!isPlaying);
          addConsoleLog('INFO', !isPlaying ? 'Simulation Engine started (60 FPS)' : 'Simulation paused');
        }}
        onStop={() => {
          setIsPlaying(false);
          addConsoleLog('INFO', 'Simulation stopped & reset to frame 0');
        }}
        selectedAsset={selectedAsset}
        onSelectAsset={(asset) => {
          setSelectedAsset(asset);
          addConsoleLog('INFO', `Active target character switched to: ${asset}`);
        }}
        isDrawerOpen={isDrawerOpen}
        onToggleDrawer={() => setIsDrawerOpen((prev) => !prev)}
        activePage={activePage}
        onSelectPage={(page) => {
          setActivePage(page);
          addConsoleLog('INFO', `Switched studio view mode to: ${page === 'movie' ? 'Cinematic Movie Studio' : 'Interactive Game Studio'}`);
        }}
        onImportNPC={handleImportNPC}
        onExportNPC={handleExportNPC}
        onImportAsset={handleImportAsset}
        onExportAsset={handleExportAsset}
      />

      {/* 2. MAIN WORKSPACE WITH VIEW ROUTING */}
      {activePage === 'game' ? (
        /* GAME STUDIO: Left Drawer + 3D Viewport + Debug Console + AI Behavior Graph */
        <div className="flex-1 flex overflow-hidden relative">
          {/* COLLAPSIBLE / PINNABLE LEFT DRAWER */}
          <LeftDrawer
            isOpen={isDrawerOpen}
            onToggleOpen={() => setIsDrawerOpen((prev) => !prev)}
            isPinned={isDrawerPinned}
            onTogglePinned={() => setIsDrawerPinned((prev) => !prev)}
            selectedAsset={selectedAsset}
            assetTree={assetTree}
            onSelectAsset={handleSelectAssetItem}
            onToggleFolder={handleToggleFolder}
            transform={transform}
            onTransformChange={handleTransformChange}
            materials={materials}
            onMaterialUpdate={handleMaterialUpdate}
          />

          {/* CENTER EXPANDED WORKSPACE: 3D Viewport (Top) & Debug Console (Bottom Drawer) */}
          <div className="flex-1 flex flex-col border-r border-[#27272a] bg-[#0d0d11] min-w-0 overflow-hidden relative">
            {/* 3D Viewport Canvas (Gains full height when Debug Console drawer is collapsed) */}
            <div className="flex-1 relative overflow-hidden">
              <Viewport3D
                selectedAsset={selectedAsset}
                transform={transform}
                isPlaying={isPlaying}
                onSelectAsset={(asset) => {
                  setSelectedAsset(asset);
                  addConsoleLog('INFO', `Active Scene Asset switched to: ${asset}`);
                }}
                onLogMessage={addConsoleLog}
                spawnedObjects={spawnedObjects}
                onAddSpawnedObject={handleAddSpawnedObject}
                onDeleteSpawnedObject={handleDeleteSpawnedObject}
                selectedSpawnedId={selectedSpawnedId}
                onSelectSpawnedId={setSelectedSpawnedId}
                motionPreset={motionPreset}
                onMotionPresetChange={setMotionPreset}
                playbackSpeed={playbackSpeed}
                onPlaybackSpeedChange={setPlaybackSpeed}
              />
            </div>

            {/* Bottom Collapsible Debug Console Drawer */}
            {isDebugConsoleOpen && (
              <div className="h-48 shrink-0 transition-all duration-200 ease-in-out border-t border-[#27272a]">
                <DebugConsole
                  logs={consoleLogs}
                  onClearLogs={handleClearLogs}
                  onAddLog={addConsoleLog}
                  isOpen={isDebugConsoleOpen}
                  onToggleOpen={() => setIsDebugConsoleOpen((prev) => !prev)}
                  motionPreset={motionPreset}
                  onSelectMotionPreset={setMotionPreset}
                  playbackSpeed={playbackSpeed}
                  onSelectPlaybackSpeed={setPlaybackSpeed}
                />
              </div>
            )}
          </div>

          {/* RIGHT PANEL: AI Behavior Graph Editor (Node Blueprint Workspace) */}
          <div className="w-[450px] lg:w-[480px] xl:w-[540px] shrink-0 flex flex-col bg-[#101014] overflow-hidden">
            <BehaviorGraphEditor
              nodes={behaviorNodes}
              connections={connections}
              onNodeMove={handleNodeMove}
              isPlaying={isPlaying}
              onAddNode={handleAddNode}
            />
          </div>
        </div>
      ) : (
        /* MOVIE STUDIO: Dedicated Cinematic Director Sequencer with Multi-Track Timeline */
        <div className="flex-1 flex overflow-hidden relative">
          <LeftDrawer
            isOpen={isDrawerOpen}
            onToggleOpen={() => setIsDrawerOpen((prev) => !prev)}
            isPinned={isDrawerPinned}
            onTogglePinned={() => setIsDrawerPinned((prev) => !prev)}
            selectedAsset={selectedAsset}
            assetTree={assetTree}
            onSelectAsset={handleSelectAssetItem}
            onToggleFolder={handleToggleFolder}
            transform={transform}
            onTransformChange={handleTransformChange}
            materials={materials}
            onMaterialUpdate={handleMaterialUpdate}
          />
          <MovieStudioView
            selectedAsset={selectedAsset}
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying(!isPlaying)}
          />
        </div>
      )}

      {/* 3. COLLAPSIBLE BOTTOM QUICK ACTION ASSETS DRAWER (SLIDES UP/DOWN) */}
      <BottomQuickAssetsDrawer
        isOpen={isQuickAssetsDrawerOpen}
        onToggleOpen={() => setIsQuickAssetsDrawerOpen((prev) => !prev)}
        onSpawnAsset={handleSpawnAsset}
        spawnedCount={spawnedObjects.length}
        onClearSpawned={handleClearAllSpawned}
      />

      {/* 4. FOOTER STATUS BAR (WITH CONTENT DRAWER, QUICK PROPS DRAWER, DEBUG CONSOLE DRAWER) */}
      <FooterStatusBar
        isPlaying={isPlaying}
        totalLogs={consoleLogs.length}
        isDrawerOpen={isDrawerOpen}
        onToggleDrawer={() => setIsDrawerOpen((prev) => !prev)}
        isQuickAssetsDrawerOpen={isQuickAssetsDrawerOpen}
        onToggleQuickAssetsDrawer={() => setIsQuickAssetsDrawerOpen((prev) => !prev)}
        placedPropsCount={spawnedObjects.length}
        isDebugConsoleOpen={isDebugConsoleOpen}
        onToggleDebugConsole={() => setIsDebugConsoleOpen((prev) => !prev)}
      />

      {/* 5. MOVABLE, MINIMIZABLE ALICE AI FLOATING PROMPT BUBBLE */}
      <FloatingAiBuilderBubble
        activeProjectMode={activePage}
        onBuildPrompt={(prompt, mode) => {
          addConsoleLog(
            'NEURAL',
            `Alice AI Prompt executed [${mode.toUpperCase()}]: "${prompt}"`
          );
          if (mode === 'game' && activePage !== 'game') {
            setActivePage('game');
          } else if (mode === 'movie' && activePage !== 'movie') {
            setActivePage('movie');
          }
        }}
      />

      {/* 6. RIGHT-CLICK CONTEXT MENU (DELETE, REDO, DATABASE, AI TYPE) */}
      <ContextMenu
        isOpen={contextMenu.isOpen}
        x={contextMenu.x}
        y={contextMenu.y}
        onClose={() => setContextMenu((prev) => ({ ...prev, isOpen: false }))}
        hasSelection={!!selectedSpawnedId}
        onDelete={() => {
          if (selectedSpawnedId) {
            const obj = spawnedObjects.find((o) => o.id === selectedSpawnedId);
            handleDeleteSpawnedObject(selectedSpawnedId);
            addConsoleLog('INFO', `Context Menu: Deleted prop [${obj?.name || selectedSpawnedId}]`);
          } else {
            addConsoleLog('INFO', 'Context Menu: Delete option triggered');
          }
        }}
        onRedo={() => {
          addConsoleLog('INFO', 'Context Menu: Redo action executed (Ctrl+Y)');
        }}
        onDatabaseOption={() => {
          addConsoleLog('INFO', 'Context Menu: Database Option clicked');
        }}
        onAiTypeOption={() => {
          addConsoleLog('INFO', 'Context Menu: AI Type Option clicked');
        }}
      />
    </div>
  );
}
