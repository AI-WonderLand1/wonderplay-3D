# WonderPlay-3D Keyboard Shortcuts Reference & Guide

This document lists all active keyboard shortcuts implemented in WonderPlay-3D Studio and how to perform each action.

---

## 🕹️ 1. Simulation & Engine Controls

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`Space`** | **Play / Pause Simulation** | Starts or pauses the real-time 3D simulation tick, AI perception loop, and neural decision stream (60 FPS). |
| **`Tab`** | **Switch Studio View** | Toggles workspace mode between **Interactive Game Studio** and **Cinematic Movie Studio** (Sequencer & Cameras). |

---

## 📂 2. Panels, Drawers & Workspaces

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`Ctrl + B`** / **`Cmd + B`** | **Toggle Left Drawer** | Opens or collapses the Left Drawer containing the **Asset Browser**, **Details Panel**, **Reality Capture Pipeline**, and **WonderCanvas Stats**. |
| **`Ctrl + \``** / **`Alt + D`** / **`Ctrl + J`** | **Toggle Debug Console** | Expands or collapses the bottom **Debug Console Drawer** to view runtime logs, neural decisions, and WebRTC streaming logs. |
| **`Alt + A`** / **`Ctrl + Q`** | **Toggle Quick Props Drawer** | Opens or closes the bottom **Quick Action Props & Assets Drawer** for 1-click scene placement. |
| **`Escape`** | **Deselect / Close Drawers** | Deselects currently highlighted 3D prop/asset in the viewport, or closes active floating drawers. |

---

## 🏃 3. NPC Motion & Animation Presets

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`1`** | **Step In-Place** | Switches the active humanoid avatar to the walking/stepping in-place locomotion rig. |
| **`2`** | **Idle Breathe** | Switches avatar to natural breathing and subtle procedural weight-shifting stance. |
| **`3`** | **Combat Stance** | Activates the combat-ready alert stance with raised posture and tactical balance. |
| **`4`** | **Dialogue Gestures** | Engages real-time conversational hand gestures and speech cadence posing. |
| **`[`** | **Decrease Playback Speed** | Steps animation playback speed down (e.g. `1.0x` ➔ `0.5x`). |
| **`]`** | **Increase Playback Speed** | Steps animation playback speed up (e.g. `1.0x` ➔ `1.5x` ➔ `2.0x`). |

---

## 🎯 4. Scene & 3D Object Editing

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`Delete`** / **`Backspace`** | **Delete Selected Prop** | Deletes the currently selected 3D prop (boxes, foliage, vehicle, rocks) from the stage. |
| **`Click & Drag (Canvas)`** | **3D Camera Orbit** | Rotates and orbits the 3D perspective around the center character rig in real time. |

---

## 💾 5. File, Import & Export

| Shortcut | Action | Description |
| :--- | :--- | :--- |
| **`Ctrl + S`** / **`Cmd + S`** | **Save Project** | Saves current scene configuration, materials, and behavior tree state. |
| **`Ctrl + Shift + E`** | **Export NPC Package** | Exports and downloads `${selectedAsset}_NPC_Package.json` with humanoid rig, blendshapes, materials, and AI behavior graph. |
| **`Ctrl + E`** | **Export Scene Assets** | Exports and downloads `WonderPlay_Scene_Assets_Manifest.json` with all scene props, hierarchy, and WonderCanvas pipeline settings. |

---

## 🖱️ 6. Mouse Context Menu Actions

| Mouse Action | Menu Option | Description |
| :--- | :--- | :--- |
| **`Right-Click` (Anywhere)** | **Context Menu** | Opens the floating studio context menu at cursor coordinates. |
| ↳ *Menu Item* | **Delete** | Deletes the currently selected scene prop or active selection. |
| ↳ *Menu Item* | **Redo** | Triggers the Redo command action. |
| ↳ *Menu Item* | **Database** | Opens the Database integration options. |
| ↳ *Menu Item* | **AI Type** | Opens the Neural AI Agent model type options. |

---

## 💡 Notes & Best Practices

- **Text Fields**: When typing inside search fields, command lines, or prompt bubbles, letter/number shortcuts (`Space`, `1-4`, `Tab`) are automatically suppressed so you can type freely.
- **Global Modifiers**: Control combinations (`Ctrl+B`, `Ctrl+S`, `Ctrl+E`, `Alt+A`, `Ctrl+\``) work at any time across the studio.
