import React, { useState } from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'sm',
  showText = true,
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);

  // Dimension scaling
  const iconDimensions = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  }[size];

  return (
    <div className={`flex items-center space-x-2 select-none ${className}`}>
      {/* 3D SYSTEMS EMBLEM (Tie-Dye Rainbow 3D Isometric Cube with 3, D, S facets) */}
      {!imgError ? (
        <img
          src="/3DSYSTEMSIMAGE.png"
          alt="3D Systems with AI-WonderPlay"
          onError={() => setImgError(true)}
          className={`${iconDimensions} object-contain shrink-0`}
        />
      ) : (
        <div className={`relative ${iconDimensions} shrink-0 flex items-center justify-center`}>
          <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)]">
            <defs>
              {/* Vibrant Rainbow Tie-Dye Swirl Gradients */}
              <radialGradient id="tiedyegrad1" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ff0055" />
                <stop offset="20%" stopColor="#ff7700" />
                <stop offset="40%" stopColor="#ffee00" />
                <stop offset="60%" stopColor="#00dd55" />
                <stop offset="80%" stopColor="#0099ff" />
                <stop offset="100%" stopColor="#7700ff" />
              </radialGradient>
              <radialGradient id="tiedyegrad2" cx="30%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#ff0088" />
                <stop offset="25%" stopColor="#ff9900" />
                <stop offset="50%" stopColor="#00dd77" />
                <stop offset="75%" stopColor="#0088ff" />
                <stop offset="100%" stopColor="#9900ff" />
              </radialGradient>
              <linearGradient id="tiedyegrad3" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0044" />
                <stop offset="25%" stopColor="#ffcc00" />
                <stop offset="50%" stopColor="#00ff88" />
                <stop offset="75%" stopColor="#00bbff" />
                <stop offset="100%" stopColor="#cc00ff" />
              </linearGradient>
            </defs>

            {/* Isometric 3D Tie-Dye Cube Facets */}
            {/* Left Top Facet (3 shape) */}
            <path
              d="M57 14 L22 36 Q18 39 20 44 L50 63 Q54 65 57 61 L57 14 Z"
              fill="url(#tiedyegrad1)"
            />
            {/* Right Top Facet (D shape) */}
            <path
              d="M63 14 L98 36 Q102 39 100 44 L70 63 Q66 65 63 61 L63 14 Z"
              fill="url(#tiedyegrad2)"
            />
            {/* Bottom Facet (S shape) */}
            <path
              d="M26 49 L58 68 Q60 69 62 68 L94 49 Q98 47 94 54 L63 104 Q60 108 57 104 L26 54 Q22 47 26 49 Z"
              fill="url(#tiedyegrad3)"
            />

            {/* Tie-Dye Swirl Overlay Lines */}
            <path
              d="M32 30 Q44 38 38 48 Q32 54 44 59"
              stroke="#ffffff"
              strokeWidth="2.8"
              fill="none"
              strokeLinecap="round"
              opacity="0.9"
            />
            <path
              d="M72 26 L72 52 Q84 46 84 38 Q84 28 72 26 Z"
              stroke="#ffffff"
              strokeWidth="2.8"
              fill="#ffffff"
              fillOpacity="0.25"
              strokeLinejoin="round"
            />
            <path
              d="M48 76 Q60 70 72 78 Q60 86 72 94"
              stroke="#ffffff"
              strokeWidth="2.8"
              fill="none"
              strokeLinecap="round"
              opacity="0.9"
            />

            {/* TM indicator */}
            <text x="102" y="98" fill="#a1a1aa" fontSize="10" fontFamily="sans-serif" fontWeight="bold">TM</text>
          </svg>
        </div>
      )}

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center space-x-1">
            <span className="font-extrabold tracking-wider text-white text-xs font-sans uppercase">
              WonderPlay-3D
            </span>
            <span className="text-[9px] font-bold text-sky-400 font-mono bg-sky-950/80 px-1 rounded border border-sky-500/40">
              AI
            </span>
          </div>
          {size !== 'sm' && (
            <span className="text-[9px] text-zinc-400 font-mono tracking-tight">
              3D SYSTEMS WITH AI-WONDERPLAY®
            </span>
          )}
        </div>
      )}
    </div>
  );
};
