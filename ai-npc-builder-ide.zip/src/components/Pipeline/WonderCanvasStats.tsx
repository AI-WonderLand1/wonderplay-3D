import React from 'react';
import {
  Activity,
  Layers,
  Cpu,
  Zap,
  Box,
  Image,
  Flame,
  ShieldAlert,
  BarChart3,
  Server,
} from 'lucide-react';

interface WonderCanvasStatsProps {
  isPlaying: boolean;
}

export const WonderCanvasStats: React.FC<WonderCanvasStatsProps> = ({ isPlaying }) => {
  return (
    <div className="flex-1 flex flex-col bg-[#141417] text-zinc-300 text-xs overflow-y-auto custom-scrollbar p-3 space-y-4 select-none font-mono">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded bg-emerald-950/80 border border-emerald-600/40 text-emerald-400">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-semibold text-white text-xs">WonderCanvas Runtime Engine</h3>
            <p className="text-[10px] text-zinc-500">Integrated High-Performance Graphics & Compute</p>
          </div>
        </div>

        <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-600/40 text-emerald-400 text-[10px] font-bold">
          WonderCanvas Active
        </span>
      </div>

      {/* Primary KPI Metrics */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-zinc-900/90 border border-zinc-800 p-2.5 rounded flex flex-col">
          <span className="text-[10px] text-zinc-500">FPS / Frame Time</span>
          <span className="text-sm font-bold text-emerald-400 mt-0.5">{isPlaying ? '60.0 FPS' : '59.2 FPS'}</span>
          <span className="text-[9px] text-zinc-400">16.6ms / frame</span>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800 p-2.5 rounded flex flex-col">
          <span className="text-[10px] text-zinc-500">Draw Calls</span>
          <span className="text-sm font-bold text-sky-400 mt-0.5">24</span>
          <span className="text-[9px] text-zinc-400">Batched (12 instances)</span>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800 p-2.5 rounded flex flex-col">
          <span className="text-[10px] text-zinc-500">Rendered Tris</span>
          <span className="text-sm font-bold text-amber-400 mt-0.5">38,420</span>
          <span className="text-[9px] text-zinc-400">LOD 0 Active</span>
        </div>
      </div>

      {/* VRAM Texture & Mesh Memory Breakdown */}
      <div className="bg-zinc-900/80 border border-zinc-800 p-3 rounded-lg space-y-2.5">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-zinc-300 font-semibold flex items-center space-x-1.5">
            <Server className="w-3.5 h-3.5 text-sky-400" />
            <span>WonderCanvas VRAM Allocation</span>
          </span>
          <span className="text-sky-400 font-bold">48.2 MB / 4096 MB</span>
        </div>

        {/* Stacked Memory Bar */}
        <div className="w-full h-3 bg-zinc-950 rounded overflow-hidden flex border border-zinc-800">
          <div className="bg-sky-500 h-full" style={{ width: '58%' }} title="PBR Textures: 28MB" />
          <div className="bg-amber-500 h-full" style={{ width: '22%' }} title="Mesh Geometry: 10.6MB" />
          <div className="bg-emerald-500 h-full" style={{ width: '12%' }} title="Skeletons & Morph Targets: 5.8MB" />
          <div className="bg-purple-500 h-full" style={{ width: '8%' }} title="Shaders & Compute Buffers: 3.8MB" />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 gap-1.5 text-[10px] pt-1">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded bg-sky-500" />
            <span className="text-zinc-400">PBR Textures (28.0 MB)</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded bg-amber-500" />
            <span className="text-zinc-400">Mesh Buffers (10.6 MB)</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded bg-emerald-500" />
            <span className="text-zinc-400">IK Armature (5.8 MB)</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded bg-purple-500" />
            <span className="text-zinc-400">WGSL Shaders (3.8 MB)</span>
          </div>
        </div>
      </div>

      {/* WonderCanvas Entity Hierarchy */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
          WonderCanvas Entity Root
        </span>

        <div className="bg-zinc-900/60 border border-zinc-800 rounded p-2 text-[10px] space-y-1">
          <div className="text-zinc-300 font-semibold flex items-center space-x-1">
            <Box className="w-3 h-3 text-sky-400" />
            <span>Root (wonder.Entity)</span>
          </div>
          <div className="pl-4 text-zinc-400 border-l border-zinc-800 ml-1.5 space-y-1">
            <div className="flex items-center justify-between text-zinc-300">
              <span>├── Camera_Perspective</span>
              <span className="text-[9px] text-zinc-500">camera component</span>
            </div>
            <div className="flex items-center justify-between text-zinc-300">
              <span>├── Light_Key_Directional</span>
              <span className="text-[9px] text-amber-500">light (shadows: PCF5)</span>
            </div>
            <div className="flex items-center justify-between text-sky-300 font-medium">
              <span>└── SK_DigitalHuman_01 (GLB)</span>
              <span className="text-[9px] text-emerald-400">render + anim + script</span>
            </div>
            <div className="pl-4 text-zinc-500 border-l border-zinc-800 ml-1.5 space-y-0.5">
              <div>├── script: NpcBrainController.ts</div>
              <div>├── script: WebRtcAudioLipSync.ts</div>
              <div>└── script: DynamicMaterialPBR.ts</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
