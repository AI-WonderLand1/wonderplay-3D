import React, { useState } from 'react';
import {
  Box,
  Car,
  Trees,
  CircleDot,
  Lightbulb,
  ShieldAlert,
  Flame,
  Plane,
  Sparkles,
  Layers,
  GripVertical,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  X,
  Search,
  SlidersHorizontal,
  Info,
} from 'lucide-react';
import { QuickActionAsset, SceneSpawnedObject } from '../../types';

export const QUICK_ACTION_ASSETS: QuickActionAsset[] = [
  {
    id: 'box_cargo_crate',
    name: 'Wooden Crate',
    category: 'prop',
    icon: '📦',
    polyCount: '1.2k tris',
    color: '#d97706',
    description: 'Stackable physics cargo container',
    defaultScale: 1,
  },
  {
    id: 'box_scifi_container',
    name: 'Sci-Fi Metal Box',
    category: 'prop',
    icon: '🧰',
    polyCount: '2.4k tris',
    color: '#0284c7',
    description: 'Armored hermetic alloy crate',
    defaultScale: 1,
  },
  {
    id: 'rock_granite_boulder',
    name: 'Granite Rock',
    category: 'prop',
    icon: '🪨',
    polyCount: '3.6k tris',
    color: '#71717a',
    description: 'Procedural photogrammetry rock',
    defaultScale: 1.2,
  },
  {
    id: 'rock_mossy_stone',
    name: 'Cliff Moss Stone',
    category: 'prop',
    icon: '⛰️',
    polyCount: '4.1k tris',
    color: '#059669',
    description: 'Weathered natural stone formation',
    defaultScale: 1.1,
  },
  {
    id: 'vehicle_cyber_car',
    name: 'Cyber Hover Car',
    category: 'vehicle',
    icon: '🚗',
    polyCount: '18.4k tris',
    color: '#38bdf8',
    description: 'Antigravity street sedan vehicle',
    defaultScale: 1.5,
  },
  {
    id: 'vehicle_combat_rover',
    name: 'Dune Buggy Rover',
    category: 'vehicle',
    icon: '🚙',
    polyCount: '24.1k tris',
    color: '#ea580c',
    description: 'All-terrain armored exploration craft',
    defaultScale: 1.4,
  },
  {
    id: 'foliage_pine_tree',
    name: 'Pine Tree',
    category: 'foliage',
    icon: '🌲',
    polyCount: '8.2k tris',
    color: '#16a34a',
    description: 'High-density alpine pine tree',
    defaultScale: 1.6,
  },
  {
    id: 'foliage_neon_palm',
    name: 'Neon Cyber Palm',
    category: 'foliage',
    icon: '🌴',
    polyCount: '6.5k tris',
    color: '#10b981',
    description: 'Synthesized bioluminescent tree',
    defaultScale: 1.4,
  },
  {
    id: 'prop_fuel_barrel',
    name: 'Explosive Barrel',
    category: 'prop',
    icon: '🛢️',
    polyCount: '1.8k tris',
    color: '#ef4444',
    description: 'Pressurized volatile fuel drum',
    defaultScale: 1,
  },
  {
    id: 'structure_barrier',
    name: 'Concrete Barrier',
    category: 'structure',
    icon: '🧱',
    polyCount: '1.1k tris',
    color: '#a1a1aa',
    description: 'Heavy modular barricade obstacle',
    defaultScale: 1.2,
  },
  {
    id: 'lighting_spot_rig',
    name: 'Stage Spot Light',
    category: 'lighting',
    icon: '💡',
    polyCount: '3.0k tris',
    color: '#facc15',
    description: 'Key spotlight & volumetric beam rig',
    defaultScale: 1.2,
  },
  {
    id: 'vehicle_patrol_drone',
    name: 'Combat Drone',
    category: 'vehicle',
    icon: '🚁',
    polyCount: '9.8k tris',
    color: '#a855f7',
    description: 'AI-controlled aerial surveillance drone',
    defaultScale: 1,
  },
];

interface BottomQuickAssetsDrawerProps {
  isOpen: boolean;
  onToggleOpen: () => void;
  onSpawnAsset: (asset: QuickActionAsset) => void;
  spawnedCount: number;
  onClearSpawned: () => void;
}

export const BottomQuickAssetsDrawer: React.FC<BottomQuickAssetsDrawerProps> = ({
  isOpen,
  onToggleOpen,
  onSpawnAsset,
  spawnedCount,
  onClearSpawned,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [draggingItemId, setDraggingItemId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredAssets = QUICK_ACTION_ASSETS.filter((item) => {
    const matchesCategory = selectedFilter === 'all' || item.category === selectedFilter;
    const matchesSearch =
      searchQuery === '' ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDragStart = (e: React.DragEvent, asset: QuickActionAsset) => {
    setDraggingItemId(asset.id);
    const dragPayload = {
      source: 'quick-assets-bar',
      id: asset.id,
      name: asset.name,
      category: asset.category,
      icon: asset.icon,
      polyCount: asset.polyCount,
      color: asset.color,
      defaultScale: asset.defaultScale || 1,
    };
    e.dataTransfer.setData('application/json', JSON.stringify(dragPayload));
    e.dataTransfer.setData('text/plain', asset.name);
    e.dataTransfer.effectAllowed = 'copyMove';

    if (e.dataTransfer.setDragImage) {
      const dragBadge = document.createElement('div');
      dragBadge.style.position = 'absolute';
      dragBadge.style.top = '-1000px';
      dragBadge.style.padding = '6px 12px';
      dragBadge.style.background = '#09090b';
      dragBadge.style.border = `1px solid ${asset.color}`;
      dragBadge.style.color = '#ffffff';
      dragBadge.style.borderRadius = '8px';
      dragBadge.style.fontSize = '12px';
      dragBadge.style.fontWeight = 'bold';
      dragBadge.style.display = 'flex';
      dragBadge.style.alignItems = 'center';
      dragBadge.style.gap = '6px';
      dragBadge.style.boxShadow = '0 10px 25px rgba(0,0,0,0.85)';
      dragBadge.innerHTML = `<span style="font-size: 16px">${asset.icon}</span> <span>${asset.name}</span>`;
      document.body.appendChild(dragBadge);
      e.dataTransfer.setDragImage(dragBadge, 15, 15);
      setTimeout(() => document.body.removeChild(dragBadge), 0);
    }
  };

  const handleDragEnd = () => {
    setDraggingItemId(null);
  };

  return (
    <div className="bg-[#111116] border-t-2 border-amber-500/40 shadow-[0_-10px_30px_rgba(0,0,0,0.6)] select-none flex flex-col z-40 animate-in slide-in-from-bottom duration-150 shrink-0">
      {/* Drawer Title & Filter Toolbar Header */}
      <div className="px-3 py-1.5 flex items-center justify-between bg-[#14141a] border-b border-zinc-800/90 text-xs">
        {/* Left: Title & Quick Drag Instruction */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1.5 font-bold font-sans tracking-wide text-zinc-200">
            <span className="p-1 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
              <Box className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-mono uppercase tracking-wider text-amber-300">
              Quick Action Props Drawer
            </span>
          </div>

          <div className="hidden sm:flex items-center text-[10px] text-zinc-400 font-mono bg-zinc-900 border border-zinc-800 rounded px-2 py-0.5 space-x-1">
            <span className="text-sky-400">Drag & Drop</span>
            <span>onto 3D Viewport canvas to place in real-time</span>
          </div>
        </div>

        {/* Center/Right: Category Filters, Search, Placed Badge, and Close Button */}
        <div className="flex items-center space-x-2">
          {/* Search Box */}
          <div className="hidden md:flex items-center bg-zinc-950 border border-zinc-800 rounded px-2 py-0.5 text-[11px] space-x-1 w-32 focus-within:w-44 focus-within:border-sky-500 transition-all">
            <Search className="w-3 h-3 text-zinc-500 shrink-0" />
            <input
              type="text"
              placeholder="Search props..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-white focus:outline-none w-full text-[10px] font-mono"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center bg-[#0a0a0e] border border-zinc-800 rounded p-0.5 text-[10px] font-mono space-x-0.5">
            {[
              { id: 'all', label: 'All' },
              { id: 'prop', label: 'Boxes & Rocks' },
              { id: 'vehicle', label: 'Cars & Drones' },
              { id: 'foliage', label: 'Trees' },
              { id: 'lighting', label: 'Lights' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id)}
                className={`px-2 py-0.5 rounded transition-colors ${
                  selectedFilter === f.id
                    ? 'bg-zinc-800 text-amber-300 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Placed objects telemetry & clear button */}
          {spawnedCount > 0 && (
            <div className="flex items-center space-x-1 bg-amber-950/60 border border-amber-600/40 rounded px-2 py-0.5 text-[10px] font-mono text-amber-300">
              <span>Scene Props: {spawnedCount}</span>
              <button
                onClick={onClearSpawned}
                title="Clear all spawned props from scene"
                className="hover:text-rose-400 p-0.5 rounded ml-1 text-zinc-400 hover:bg-rose-950/60 transition-colors"
              >
                <Trash2 className="w-2.5 h-2.5" />
              </button>
            </div>
          )}

          {/* Close / Collapse Drawer Button */}
          <button
            onClick={onToggleOpen}
            title="Close Quick Props Drawer [Alt+A]"
            className="p-1 text-zinc-400 hover:text-white rounded hover:bg-zinc-800 transition-colors flex items-center space-x-1 border border-zinc-800"
          >
            <ChevronDown className="w-3.5 h-3.5 text-zinc-300" />
            <span className="text-[10px] font-mono font-bold pr-0.5">Hide</span>
          </button>
        </div>
      </div>

      {/* Draggable Assets Grid Strip */}
      <div className="p-2.5 px-3 flex items-center gap-2.5 overflow-x-auto no-scrollbar bg-[#0c0c10] min-h-[76px]">
        {filteredAssets.length === 0 ? (
          <div className="w-full py-4 text-center text-xs text-zinc-500 font-mono">
            No props match "{searchQuery}" in this category.
          </div>
        ) : (
          filteredAssets.map((asset) => {
            const isDragging = draggingItemId === asset.id;
            return (
              <div
                key={asset.id}
                draggable
                onDragStart={(e) => handleDragStart(e, asset)}
                onDragEnd={handleDragEnd}
                onClick={() => onSpawnAsset(asset)}
                title={`Drag into 3D Viewport or click to spawn: ${asset.name} (${asset.description})`}
                className={`flex-shrink-0 group relative flex items-center space-x-2 bg-[#16161c] hover:bg-[#20202a] border border-zinc-800 hover:border-amber-500/70 rounded-lg p-1.5 px-3 cursor-grab active:cursor-grabbing transition-all hover:scale-[1.02] shadow-sm ${
                  isDragging ? 'opacity-40 border-amber-400 border-dashed bg-amber-950/40' : ''
                }`}
              >
                {/* Drag Grip Handle */}
                <GripVertical className="w-3.5 h-3.5 text-zinc-600 group-hover:text-amber-400 opacity-40 group-hover:opacity-100 transition-opacity shrink-0" />

                {/* Big Emoji / Vector Icon Container */}
                <div
                  className="w-9 h-9 rounded-md bg-[#0e0e13] border border-zinc-800 flex items-center justify-center text-xl shadow-inner group-hover:border-amber-500/50 group-hover:shadow-[0_0_14px_rgba(245,158,11,0.25)] transition-all"
                  style={{ borderColor: `${asset.color}50` }}
                >
                  <span>{asset.icon}</span>
                </div>

                {/* Name, Polycount, and Category */}
                <div className="flex flex-col text-left pr-1">
                  <div className="flex items-center space-x-1">
                    <span className="text-xs font-semibold text-zinc-100 group-hover:text-amber-300 transition-colors font-sans whitespace-nowrap">
                      {asset.name}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1.5 text-[9px] font-mono text-zinc-500">
                    <span className="text-zinc-400">{asset.polyCount}</span>
                    <span>•</span>
                    <span className="uppercase text-amber-400/90 font-bold">{asset.category}</span>
                  </div>
                </div>

                {/* Quick Add Plus Pill on Hover */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSpawnAsset(asset);
                  }}
                  title="Quick Place on Scene Center"
                  className="opacity-0 group-hover:opacity-100 p-1 bg-amber-600 hover:bg-amber-500 text-white rounded transition-all shadow-md ml-1"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
