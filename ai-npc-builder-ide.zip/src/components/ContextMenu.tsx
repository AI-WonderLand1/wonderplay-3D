import React, { useEffect, useRef } from 'react';
import {
  Trash2,
  RotateCw,
  Database,
  Bot,
  Sparkles,
} from 'lucide-react';

export interface ContextMenuProps {
  x: number;
  y: number;
  isOpen: boolean;
  onClose: () => void;
  onDelete?: () => void;
  onRedo?: () => void;
  onDatabaseOption?: () => void;
  onAiTypeOption?: () => void;
  hasSelection?: boolean;
}

export const ContextMenu: React.FC<ContextMenuProps> = ({
  x,
  y,
  isOpen,
  onClose,
  onDelete,
  onRedo,
  onDatabaseOption,
  onAiTypeOption,
  hasSelection = false,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  // Close on outside click or escape
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDown = (e: PointerEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Clamp within window dimensions
  const menuWidth = 190;
  const menuHeight = 160;
  const clampedX = Math.min(Math.max(10, x), window.innerWidth - menuWidth - 10);
  const clampedY = Math.min(Math.max(10, y), window.innerHeight - menuHeight - 10);

  return (
    <div
      ref={menuRef}
      id="studio-context-menu"
      style={{ left: `${clampedX}px`, top: `${clampedY}px` }}
      className="fixed z-50 w-48 bg-[#18181b]/95 backdrop-blur-md border border-zinc-700/80 rounded-lg shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_15px_rgba(0,0,0,0.5)] p-1 text-xs text-zinc-200 font-sans select-none animate-in fade-in-50 zoom-in-95 duration-100 divide-y divide-zinc-800/80"
    >
      {/* Action Group 1: Delete & Redo */}
      <div className="py-0.5">
        {/* Delete Option */}
        <button
          id="context-menu-delete-btn"
          onClick={() => {
            onDelete?.();
            onClose();
          }}
          className="w-full text-left px-2.5 py-1.5 rounded hover:bg-rose-900/60 hover:text-rose-100 flex items-center justify-between text-zinc-300 transition-colors group"
        >
          <div className="flex items-center space-x-2">
            <Trash2 className="w-3.5 h-3.5 text-rose-400 group-hover:text-rose-200" />
            <span className="font-medium text-rose-300 group-hover:text-rose-100">Delete</span>
          </div>
          <span className="text-[10px] text-zinc-500 group-hover:text-zinc-300 font-mono">Del</span>
        </button>

        {/* Redo (Redue) Option */}
        <button
          id="context-menu-redo-btn"
          onClick={() => {
            onRedo?.();
            onClose();
          }}
          className="w-full text-left px-2.5 py-1.5 rounded hover:bg-sky-600 hover:text-white flex items-center justify-between text-zinc-300 transition-colors group"
        >
          <div className="flex items-center space-x-2">
            <RotateCw className="w-3.5 h-3.5 text-sky-400 group-hover:text-white" />
            <span className="font-medium">Redo</span>
          </div>
          <span className="text-[10px] text-zinc-500 group-hover:text-zinc-200 font-mono">Ctrl+Y</span>
        </button>
      </div>

      {/* Action Group 2: Database & AI Type Options */}
      <div className="py-0.5">
        {/* Database Option */}
        <button
          id="context-menu-database-btn"
          onClick={() => {
            onDatabaseOption?.();
            onClose();
          }}
          className="w-full text-left px-2.5 py-1.5 rounded hover:bg-emerald-600 hover:text-white flex items-center justify-between text-zinc-300 transition-colors group"
        >
          <div className="flex items-center space-x-2">
            <Database className="w-3.5 h-3.5 text-emerald-400 group-hover:text-white" />
            <span className="font-medium">Database</span>
          </div>
          <span className="text-[9px] bg-emerald-950/80 text-emerald-300 px-1 py-0.2 rounded border border-emerald-700/50 group-hover:border-transparent group-hover:bg-emerald-700 group-hover:text-white font-mono">
            DB
          </span>
        </button>

        {/* AI Type Option */}
        <button
          id="context-menu-ai-type-btn"
          onClick={() => {
            onAiTypeOption?.();
            onClose();
          }}
          className="w-full text-left px-2.5 py-1.5 rounded hover:bg-purple-600 hover:text-white flex items-center justify-between text-zinc-300 transition-colors group"
        >
          <div className="flex items-center space-x-2">
            <Bot className="w-3.5 h-3.5 text-purple-400 group-hover:text-white" />
            <span className="font-medium">AI Type</span>
          </div>
          <span className="text-[9px] bg-purple-950/80 text-purple-300 px-1 py-0.2 rounded border border-purple-700/50 group-hover:border-transparent group-hover:bg-purple-700 group-hover:text-white font-mono">
            Agent
          </span>
        </button>
      </div>
    </div>
  );
};
