import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  Move,
  RotateCw,
  Scaling,
  Grid,
  Sun,
  Monitor,
  Zap,
  Play,
  Pause,
  Bone,
  Flame,
  MessageSquare,
  Footprints,
  Wind,
  RotateCcw,
  Eye,
  Layers,
  Sparkles,
  Radio,
  CheckCircle2,
  Trash2,
  Crosshair,
  Box,
  Cpu,
} from 'lucide-react';
import { ViewportRenderMode, ViewportCameraMode, TransformState, SceneSpawnedObject, QuickActionAsset } from '../../types';
import { FullBodyNpcAvatar, NpcMotionPreset, PbrChannelMode } from './FullBodyNpcAvatar';

interface Viewport3DProps {
  selectedAsset: string;
  transform: TransformState;
  isPlaying: boolean;
  onSelectAsset?: (assetName: string) => void;
  onLogMessage?: (level: 'INFO' | 'NEURAL' | 'DEBUG' | 'WARN', message: string) => void;
  spawnedObjects?: SceneSpawnedObject[];
  onAddSpawnedObject?: (object: SceneSpawnedObject) => void;
  onDeleteSpawnedObject?: (id: string) => void;
  selectedSpawnedId?: string | null;
  onSelectSpawnedId?: (id: string | null) => void;
  motionPreset?: NpcMotionPreset;
  onMotionPresetChange?: (preset: NpcMotionPreset) => void;
  playbackSpeed?: number;
  onPlaybackSpeedChange?: (speed: number) => void;
}

export const Viewport3D: React.FC<Viewport3DProps> = ({
  selectedAsset,
  transform,
  isPlaying,
  onSelectAsset,
  onLogMessage,
  spawnedObjects = [],
  onAddSpawnedObject,
  onDeleteSpawnedObject,
  selectedSpawnedId: controlledSelectedSpawnedId,
  onSelectSpawnedId: controlledOnSelectSpawnedId,
  motionPreset: controlledMotionPreset,
  onMotionPresetChange,
  playbackSpeed: controlledPlaybackSpeed,
  onPlaybackSpeedChange,
}) => {
  const [renderMode, setRenderMode] = useState<ViewportRenderMode>('Lit');
  const [pbrChannel, setPbrChannel] = useState<PbrChannelMode>('Lit');
  const [cameraMode, setCameraMode] = useState<ViewportCameraMode>('Perspective');
  const [gizmoMode, setGizmoMode] = useState<'translate' | 'rotate' | 'scale'>('translate');
  const [showWireframe, setShowWireframe] = useState(false);
  const [showSkeleton, setShowSkeleton] = useState(false);
  const [showCameras, setShowCameras] = useState(true);
  const [localMotionPreset, setLocalMotionPreset] = useState<NpcMotionPreset>('walk-in-place');
  const [localPlaybackSpeed, setLocalPlaybackSpeed] = useState<number>(1.0);
  
  const motionPreset = controlledMotionPreset !== undefined ? controlledMotionPreset : localMotionPreset;
  const setMotionPreset = (preset: NpcMotionPreset) => {
    setLocalMotionPreset(preset);
    onMotionPresetChange?.(preset);
  };

  const playbackSpeed = controlledPlaybackSpeed !== undefined ? controlledPlaybackSpeed : localPlaybackSpeed;
  const setPlaybackSpeed = (spd: number) => {
    setLocalPlaybackSpeed(spd);
    onPlaybackSpeedChange?.(spd);
  };

  const [orbitAngle, setOrbitAngle] = useState(-5);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<number>(0);

  // Drag & Drop State
  const [isDragOver, setIsDragOver] = useState(false);
  const [dragCursorPos, setDragCursorPos] = useState<{ x: number; y: number }>({ x: 50, y: 50 });
  const [assignmentFeedback, setAssignmentFeedback] = useState<{
    text: string;
    subText: string;
    icon?: string;
  } | null>(null);

  const [localSelectedSpawnedId, setLocalSelectedSpawnedId] = useState<string | null>(null);
  const selectedSpawnedId = controlledSelectedSpawnedId !== undefined ? controlledSelectedSpawnedId : localSelectedSpawnedId;
  const setSelectedSpawnedId = (id: string | null) => {
    setLocalSelectedSpawnedId(id);
    controlledOnSelectSpawnedId?.(id);
  };

  const stageRef = useRef<HTMLDivElement>(null);

  // Auto-dismiss assignment feedback toast
  useEffect(() => {
    if (assignmentFeedback) {
      const timer = setTimeout(() => {
        setAssignmentFeedback(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [assignmentFeedback]);

  const handleMouseDown = (e: React.MouseEvent) => {
    // Avoid triggering stage orbit when clicking on HUD buttons or props
    if ((e.target as HTMLElement).closest('button, select, input, .interactive-prop')) return;
    setIsDragging(true);
    dragStartRef.current = e.clientX;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const delta = e.clientX - dragStartRef.current;
    setOrbitAngle((prev) => prev + delta * 0.4);
    dragStartRef.current = e.clientX;
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Drag and Drop Event Handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    if (!isDragOver) {
      setIsDragOver(true);
    }

    if (stageRef.current) {
      const rect = stageRef.current.getBoundingClientRect();
      const xPercent = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
      const yPercent = Math.max(0, Math.min(100, ((e.clientY - rect.top) / rect.height) * 100));
      setDragCursorPos({ x: xPercent, y: yPercent });
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (stageRef.current && !stageRef.current.contains(e.relatedTarget as Node)) {
      setIsDragOver(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    let rawData = e.dataTransfer.getData('application/json');
    let fallbackText = e.dataTransfer.getData('text/plain');

    let parsedPayload: any = null;
    if (rawData) {
      try {
        parsedPayload = JSON.parse(rawData);
      } catch (err) {
        parsedPayload = null;
      }
    }

    // Calculate stage-relative drop coordinates
    let relativeX = 0;
    let relativeY = 0;
    if (stageRef.current) {
      const rect = stageRef.current.getBoundingClientRect();
      relativeX = Math.round(((e.clientX - rect.left) / rect.width - 0.5) * 440);
      relativeY = Math.round(((e.clientY - rect.top) / rect.height - 0.5) * 160);
    }

    if (parsedPayload?.source === 'asset-browser') {
      // 1. Dropped from Asset Browser
      const assetName = parsedPayload.name || fallbackText || 'Selected Asset';
      onSelectAsset?.(assetName);
      onLogMessage?.('INFO', `Assigned asset [${assetName}] to 3D Viewport Target & Stage.`);

      setAssignmentFeedback({
        text: `Assigned "${assetName}" to Scene`,
        subText: `Mesh instance and shader bindings synchronized to WonderCanvas runtime.`,
        icon: parsedPayload.type === 'character' ? '👤' : parsedPayload.type === 'shader' ? '🎨' : '📦',
      });

      // If it's an environment prop or character from asset tree, also spawn a representation on floor
      if (parsedPayload.type === 'environment' || parsedPayload.type === 'character') {
        const newSpawn: SceneSpawnedObject = {
          id: `spawn_${Date.now()}`,
          name: assetName,
          category: parsedPayload.type === 'character' ? 'character' : 'prop',
          icon: parsedPayload.type === 'character' ? '🤖' : '🏛️',
          posX: relativeX,
          posY: relativeY,
          scale: 1,
          rotation: Math.floor(Math.random() * 60) - 30,
          color: parsedPayload.color || '#38bdf8',
          polyCount: '12.4k tris',
        };
        onAddSpawnedObject?.(newSpawn);
      }
    } else if (parsedPayload?.source === 'quick-assets-bar' || parsedPayload?.id) {
      // 2. Dropped from Quick Action Assets Drawer
      const newSpawn: SceneSpawnedObject = {
        id: `spawn_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        name: parsedPayload.name,
        category: parsedPayload.category || 'prop',
        icon: parsedPayload.icon || '📦',
        posX: relativeX,
        posY: relativeY,
        scale: parsedPayload.defaultScale || 1,
        rotation: Math.floor(Math.random() * 40) - 20,
        color: parsedPayload.color || '#38bdf8',
        polyCount: parsedPayload.polyCount || '2.0k tris',
      };

      onAddSpawnedObject?.(newSpawn);
      setSelectedSpawnedId(newSpawn.id);
      onLogMessage?.(
        'INFO',
        `Spawned quick asset [${newSpawn.name}] at 3D floor coordinates (X: ${relativeX}, Y: ${relativeY})`
      );

      setAssignmentFeedback({
        text: `Spawned ${newSpawn.name}`,
        subText: `Placed at Stage Coordinates [X: ${relativeX}, Y: ${relativeY}]`,
        icon: newSpawn.icon,
      });
    } else if (fallbackText) {
      // Generic text drop
      onSelectAsset?.(fallbackText);
      setAssignmentFeedback({
        text: `Assigned "${fallbackText}"`,
        subText: `Asset target activated in Viewport inspector.`,
        icon: '✨',
      });
    }
  };

  const handleDeleteSpawned = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onDeleteSpawnedObject?.(id);
    if (selectedSpawnedId === id) setSelectedSpawnedId(null);
  };

  return (
    <div className="flex flex-col h-full bg-[#0d0d11] relative overflow-hidden select-none">
      {/* Top Viewport Header Bar */}
      <div className="h-8 bg-[#141417] border-b border-[#27272a] px-3 flex items-center justify-between text-xs text-zinc-300 z-20 shrink-0">
        <div className="flex items-center space-x-2">
          {/* Active Viewport Icon Tab (without 3D Viewport text) */}
          <div className="flex items-center space-x-1.5 bg-[#1f1f23] px-2 py-1 rounded-t border-t-2 border-sky-500 text-sky-400">
            <Monitor className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Viewport Control Tools & User Project */}
        <div className="flex items-center space-x-2 text-zinc-400">
          {/* PBR Map Channel Selector Dropdown */}
          <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-2 py-0.5 space-x-1">
            <Layers className="w-3 h-3 text-sky-400" />
            <select
              value={pbrChannel}
              onChange={(e) => setPbrChannel(e.target.value as PbrChannelMode)}
              aria-label="PBR Map Channel"
              className="bg-transparent text-zinc-200 text-[11px] focus:outline-none cursor-pointer"
            >
              <option value="Lit" className="bg-zinc-900 text-white">Full Lit (PBR Cycles)</option>
              <option value="Albedo" className="bg-zinc-900 text-white">Albedo / Base Color</option>
              <option value="Normal" className="bg-zinc-900 text-white">Normal Map (Tangents)</option>
              <option value="ORM" className="bg-zinc-900 text-white">ORM (Rough/Metal/AO)</option>
              <option value="PointCloud" className="bg-zinc-900 text-white">Sparse Point Cloud (COLMAP)</option>
            </select>
          </div>

          {/* Motion Preset Dropdown next to Full Lit (PBR Cycles) */}
          <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-2 py-0.5 space-x-1">
            <Footprints className="w-3 h-3 text-emerald-400" />
            <select
              value={motionPreset}
              onChange={(e) => setMotionPreset(e.target.value as NpcMotionPreset)}
              aria-label="Motion Preset"
              className="bg-transparent text-zinc-200 text-[11px] focus:outline-none cursor-pointer"
            >
              <option value="walk-in-place" className="bg-zinc-900 text-white">Step In-Place</option>
              <option value="idle" className="bg-zinc-900 text-white">Idle Breathe</option>
              <option value="combat" className="bg-zinc-900 text-white">Combat Stance</option>
              <option value="dialogue" className="bg-zinc-900 text-white">Dialogue Gestures</option>
            </select>
          </div>

          {/* View Render Mode Dropdown */}
          <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-2 py-0.5 space-x-1">
            <Sun className="w-3 h-3 text-amber-400" />
            <select
              value={renderMode}
              onChange={(e) => setRenderMode(e.target.value as ViewportRenderMode)}
              aria-label="Viewport Render Mode"
              className="bg-transparent text-zinc-200 text-[11px] focus:outline-none cursor-pointer"
            >
              <option value="Lit" className="bg-zinc-900 text-white">Lit</option>
              <option value="Unlit" className="bg-zinc-900 text-white">Unlit</option>
              <option value="Wireframe" className="bg-zinc-900 text-white">Wireframe</option>
              <option value="Detailed Lighting" className="bg-zinc-900 text-white">Detailed Lighting</option>
              <option value="Path Tracing" className="bg-zinc-900 text-white">Path Tracing</option>
            </select>
          </div>

          {/* Camera Projection */}
          <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded px-2 py-0.5 space-x-1">
            <Camera className="w-3 h-3 text-sky-400" />
            <select
              value={cameraMode}
              onChange={(e) => setCameraMode(e.target.value as ViewportCameraMode)}
              aria-label="Viewport Camera Mode"
              className="bg-transparent text-zinc-200 text-[11px] focus:outline-none cursor-pointer"
            >
              <option value="Perspective" className="bg-zinc-900 text-white">Perspective</option>
              <option value="Top" className="bg-zinc-900 text-white">Top</option>
              <option value="Front" className="bg-zinc-900 text-white">Front</option>
              <option value="Right" className="bg-zinc-900 text-white">Right</option>
            </select>
          </div>

          <div className="h-3.5 w-[1px] bg-zinc-800" />

          {/* Transform Gizmo Selector */}
          <div className="flex items-center bg-[#09090b] border border-zinc-800 rounded p-0.5 space-x-0.5">
            <button
              onClick={() => setGizmoMode('translate')}
              title="Translate (W)"
              className={`p-1 rounded ${
                gizmoMode === 'translate' ? 'bg-zinc-700 text-sky-300' : 'hover:bg-zinc-800 text-zinc-400'
              }`}
            >
              <Move className="w-3 h-3" />
            </button>
            <button
              onClick={() => setGizmoMode('rotate')}
              title="Rotate (E)"
              className={`p-1 rounded ${
                gizmoMode === 'rotate' ? 'bg-zinc-700 text-amber-300' : 'hover:bg-zinc-800 text-zinc-400'
              }`}
            >
              <RotateCw className="w-3 h-3" />
            </button>
            <button
              onClick={() => setGizmoMode('scale')}
              title="Scale (R)"
              className={`p-1 rounded ${
                gizmoMode === 'scale' ? 'bg-zinc-700 text-emerald-300' : 'hover:bg-zinc-800 text-zinc-400'
              }`}
            >
              <Scaling className="w-3 h-3" />
            </button>
          </div>

          {/* Wireframe Overlay Toggle */}
          <button
            onClick={() => setShowWireframe(!showWireframe)}
            title="Toggle Wireframe Overlay"
            className={`p-1 rounded border border-zinc-800 ${
              showWireframe ? 'bg-sky-900/60 text-sky-300 border-sky-600' : 'bg-[#09090b] text-zinc-400 hover:text-white'
            }`}
          >
            <Grid className="w-3 h-3" />
          </button>

          {/* Skeletal Armature Rig Toggle */}
          <button
            onClick={() => setShowSkeleton(!showSkeleton)}
            title="Toggle Bone IK Skeleton"
            className={`p-1 rounded border border-zinc-800 flex items-center space-x-1 ${
              showSkeleton ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600' : 'bg-[#09090b] text-zinc-400 hover:text-white'
            }`}
          >
            <Bone className="w-3 h-3" />
          </button>

          {/* Photogrammetry Camera Poses Toggle */}
          <button
            onClick={() => setShowCameras(!showCameras)}
            title="Toggle Photogrammetry Camera Poses (COLMAP)"
            className={`p-1 rounded border border-zinc-800 flex items-center space-x-1 ${
              showCameras ? 'bg-purple-950/80 text-purple-300 border-purple-600' : 'bg-[#09090b] text-zinc-400 hover:text-white'
            }`}
          >
            <Radio className="w-3 h-3" />
          </button>

          <div className="h-3.5 w-[1px] bg-zinc-800" />

          {/* User Project Badge on Right Side */}
          <div className="flex items-center space-x-1 px-2 py-0.5 bg-[#09090b] border border-sky-500/40 rounded text-[11px] font-mono text-sky-400 font-semibold shadow-xs">
            <Cpu className="w-3 h-3 text-sky-400" />
            <span>User Project</span>
          </div>
        </div>
      </div>

      {/* Floating Assignment Confirmation Toast / HUD */}
      {assignmentFeedback && (
        <div className="absolute top-20 right-3 z-40 bg-zinc-950/95 border border-sky-500/80 shadow-[0_10px_30px_rgba(0,0,0,0.9),0_0_20px_rgba(56,189,248,0.3)] rounded-lg p-2.5 px-3 flex items-center space-x-3 text-white backdrop-blur-xl animate-in slide-in-from-right-4 duration-200 max-w-sm">
          <div className="text-2xl shrink-0 p-1 bg-sky-950/60 rounded border border-sky-600/50 flex items-center justify-center">
            {assignmentFeedback.icon || '✨'}
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-bold text-xs text-zinc-100 font-sans">
                {assignmentFeedback.text}
              </span>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono mt-0.5 leading-snug">
              {assignmentFeedback.subText}
            </span>
          </div>
        </div>
      )}

      {/* Orientation Axis Gizmo (Top Right) */}
      <div className="absolute top-10 right-3 z-30 pointer-events-none">
        <div className="w-16 h-16 rounded-full bg-zinc-950/60 border border-zinc-800/80 backdrop-blur-md flex items-center justify-center relative shadow-xl">
          <svg className="w-12 h-12" viewBox="-30 -30 60 60">
            {/* Center origin */}
            <circle cx="0" cy="0" r="3" fill="#ffffff" />
            {/* X Axis Red */}
            <line x1="0" y1="0" x2="20" y2="8" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round" />
            <text x="23" y="11" fill="#ef4444" fontSize="8" fontWeight="bold" fontFamily="monospace">X</text>
            {/* Y Axis Green */}
            <line x1="0" y1="0" x2="-14" y2="18" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" />
            <text x="-24" y="24" fill="#22c55e" fontSize="8" fontWeight="bold" fontFamily="monospace">Y</text>
            {/* Z Axis Blue (Up) */}
            <line x1="0" y1="0" x2="0" y2="-22" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" />
            <text x="-3" y="-25" fill="#3b82f6" fontSize="8" fontWeight="bold" fontFamily="monospace">Z</text>
          </svg>
        </div>
      </div>

      {/* 3D VIEWPORT CANVAS STAGE WITH DRAG & DROP TARGET */}
      <div
        ref={stageRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onDragOver={handleDragOver}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`flex-1 relative cursor-grab active:cursor-grabbing overflow-hidden flex items-center justify-center bg-radial from-[#181824] via-[#0b0b10] to-[#050507] transition-all ${
          isDragOver ? 'ring-2 ring-inset ring-sky-400 bg-sky-950/20' : ''
        }`}
      >
        {/* Sci-Fi Hangar Environmental Geometry (CSS & SVG Backdrop) */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Overhead Fluorescent Hangar Arches */}
          <div className="absolute top-0 inset-x-0 h-44 bg-gradient-to-b from-sky-950/20 via-zinc-900/10 to-transparent" />

          {/* Perspective Hangar Corridor Pillars */}
          <svg className="absolute inset-0 w-full h-full opacity-40" preserveAspectRatio="none">
            {/* Perspective grid lines to center vanishing point */}
            <line x1="0%" y1="0%" x2="50%" y2="45%" stroke="#38bdf8" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.3" />
            <line x1="100%" y1="0%" x2="50%" y2="45%" stroke="#38bdf8" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.3" />
            <line x1="0%" y1="100%" x2="50%" y2="55%" stroke="#0ea5e9" strokeWidth="0.8" opacity="0.4" />
            <line x1="100%" y1="100%" x2="50%" y2="55%" stroke="#0ea5e9" strokeWidth="0.8" opacity="0.4" />

            {/* Sci-Fi Corridor Hangar Pillars */}
            <polygon points="40,20 120,40 120,380 40,420" fill="#14141d" stroke="#272738" strokeWidth="1.5" />
            <polygon points="680,20 600,40 600,380 680,420" fill="#14141d" stroke="#272738" strokeWidth="1.5" />

            {/* Neon Blue Lighting Bars along corridor */}
            <line x1="60" y1="50" x2="60" y2="350" stroke="#38bdf8" strokeWidth="3" opacity="0.7" filter="drop-shadow(0 0 6px #38bdf8)" />
            <line x1="660" y1="50" x2="660" y2="350" stroke="#38bdf8" strokeWidth="3" opacity="0.7" filter="drop-shadow(0 0 6px #38bdf8)" />

            {/* Warm Amber Rim Lighting Bars */}
            <line x1="110" y1="90" x2="110" y2="300" stroke="#f59e0b" strokeWidth="2" opacity="0.6" filter="drop-shadow(0 0 4px #f59e0b)" />
            <line x1="610" y1="90" x2="610" y2="300" stroke="#f59e0b" strokeWidth="2" opacity="0.6" filter="drop-shadow(0 0 4px #f59e0b)" />
          </svg>

          {/* SciFi Floor Hologram Radial Grid */}
          <div className="absolute bottom-0 inset-x-0 h-52 bg-gradient-to-t from-sky-950/30 to-transparent flex items-center justify-center">
            <div className="w-[560px] h-[200px] rounded-[100%] border border-sky-500/30 shadow-[0_0_40px_rgba(56,189,248,0.18)] flex items-center justify-center transform -rotate-x-60">
              <div className="w-[420px] h-[140px] rounded-[100%] border border-sky-400/25" />
              <div className="w-[260px] h-[80px] rounded-[100%] border border-amber-400/25" />
            </div>
          </div>
        </div>

        {/* DYNAMIC DRAG-OVER RETICLE & HOLOGRAM DROP ZONE */}
        {isDragOver && (
          <div className="absolute inset-0 pointer-events-none z-40 flex flex-col items-center justify-center">
            {/* Ambient Radial Target Backlight */}
            <div className="w-80 h-80 rounded-full bg-sky-500/20 blur-3xl animate-pulse" />

            {/* Glowing Hologram Target Reticle */}
            <div className="relative flex flex-col items-center justify-center -mt-8">
              <div className="w-48 h-48 rounded-full border-2 border-dashed border-sky-400 animate-spin flex items-center justify-center shadow-[0_0_30px_rgba(56,189,248,0.5)]">
                <div className="w-36 h-36 rounded-full border border-sky-300/40 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full border border-dashed border-amber-400/80 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '6s' }} />
                </div>
              </div>

              {/* Center Crosshair */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Crosshair className="w-8 h-8 text-sky-300 animate-pulse drop-shadow-[0_0_8px_#38bdf8]" />
              </div>

              {/* Target Banner */}
              <div className="mt-4 px-4 py-2 bg-black/85 border border-sky-400 rounded-full shadow-[0_10px_30px_rgba(0,0,0,0.9)] backdrop-blur-md flex items-center space-x-2 text-white">
                <Sparkles className="w-4 h-4 text-sky-400 animate-bounce" />
                <span className="text-xs font-bold font-mono tracking-wide text-sky-200">
                  RELEASE TO ASSIGN & PLACE INTO SCENE
                </span>
              </div>
            </div>
          </div>
        )}

        {/* SPAWNED SCENE PROPS (Boxes, Rocks, Cars, Trees, Lights, etc.) */}
        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          {spawnedObjects.map((obj) => {
            const isSelected = selectedSpawnedId === obj.id;
            return (
              <div
                key={obj.id}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedSpawnedId(obj.id);
                  onLogMessage?.('INFO', `Selected scene prop: ${obj.name} (${obj.polyCount})`);
                }}
                className={`interactive-prop absolute pointer-events-auto cursor-pointer transition-all duration-75 group ${
                  isSelected ? 'z-30 scale-105' : 'z-10 hover:scale-105'
                }`}
                style={{
                  transform: `translate(${obj.posX}px, ${obj.posY + 70}px) scale(${obj.scale}) rotate(${obj.rotation}deg)`,
                }}
              >
                {/* Prop Shadow Ellipse */}
                <div
                  className="w-14 h-4 rounded-full bg-black/60 blur-xs mx-auto -mb-2"
                  style={{ width: `${36 * obj.scale}px` }}
                />

                {/* Prop Card / 3D Icon Representation */}
                <div
                  className={`p-2 rounded-xl border flex flex-col items-center justify-center backdrop-blur-md transition-all ${
                    isSelected
                      ? 'bg-zinc-950/90 border-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.4)]'
                      : 'bg-zinc-950/70 border-zinc-800 group-hover:border-zinc-600 group-hover:bg-zinc-900/85'
                  }`}
                  style={{
                    borderColor: isSelected ? '#38bdf8' : `${obj.color}40`,
                  }}
                >
                  <span className="text-2xl filter drop-shadow-md select-none">
                    {obj.icon}
                  </span>

                  {/* Label / Polys */}
                  <div className="mt-1 flex flex-col items-center">
                    <span className="text-[10px] font-bold text-zinc-200 font-sans tracking-tight whitespace-nowrap">
                      {obj.name}
                    </span>
                    <span className="text-[8px] font-mono text-zinc-400">
                      {obj.polyCount}
                    </span>
                  </div>

                  {/* Quick Delete button on hover or selection */}
                  <button
                    onClick={(e) => handleDeleteSpawned(obj.id, e)}
                    title="Remove from scene"
                    className="opacity-0 group-hover:opacity-100 absolute -top-2 -right-2 p-1 bg-rose-600 hover:bg-rose-500 text-white rounded-full transition-opacity shadow-md"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* FULL BODY CHARACTER 3D AVATAR MODEL DISPLAY */}
        <div
          className="relative z-10 flex flex-col items-center justify-center transition-transform duration-75"
          style={{
            transform: `rotateY(${orbitAngle + transform.rotZ}deg) translateY(${-transform.posZ * 0.4}px) scale(${transform.scaleX})`,
          }}
        >
          {/* Backlight Ambient Glow */}
          <div className="absolute -inset-10 bg-gradient-to-t from-sky-500/15 via-amber-500/10 to-transparent rounded-full blur-3xl opacity-75 pointer-events-none" />

          {/* Photogrammetry Camera Poses Array (COLMAP Sparse Frustums) */}
          {showCameras && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <svg className="w-[480px] h-[580px] overflow-visible opacity-85" viewBox="-240 -290 480 580">
                {/* Orbital Ring Path */}
                <ellipse cx="0" cy="20" rx="190" ry="70" fill="none" stroke="#a855f7" strokeWidth="0.8" strokeDasharray="3,3" opacity="0.4" />
                <ellipse cx="0" cy="-60" rx="170" ry="60" fill="none" stroke="#a855f7" strokeWidth="0.8" strokeDasharray="3,3" opacity="0.4" />
                <ellipse cx="0" cy="110" rx="180" ry="65" fill="none" stroke="#a855f7" strokeWidth="0.8" strokeDasharray="3,3" opacity="0.4" />

                {/* Ring 1 Cameras (Chest Level) */}
                {[-170, -130, -90, -50, -10, 30, 70, 110, 150].map((angle, idx) => {
                  const rad = (angle * Math.PI) / 180;
                  const x = 190 * Math.cos(rad);
                  const y = 20 + 70 * Math.sin(rad);
                  return (
                    <g key={`cam1-${idx}`} transform={`translate(${x}, ${y})`}>
                      {/* Camera body pyramid pointing to center */}
                      <circle cx="0" cy="0" r="3" fill="#c084fc" />
                      <line x1="0" y1="0" x2={-x * 0.18} y2={(-y + 20) * 0.18} stroke="#c084fc" strokeWidth="1" opacity="0.6" />
                      <polygon
                        points="-4,-4 4,-4 6,4 -6,4"
                        fill="#581c87"
                        stroke="#a855f7"
                        strokeWidth="1"
                        transform={`rotate(${(Math.atan2(-y + 20, -x) * 180) / Math.PI + 90})`}
                      />
                    </g>
                  );
                })}

                {/* Ring 2 Cameras (Head Level Elevated) */}
                {[-150, -105, -60, -15, 30, 75, 120, 165].map((angle, idx) => {
                  const rad = (angle * Math.PI) / 180;
                  const x = 170 * Math.cos(rad);
                  const y = -60 + 60 * Math.sin(rad);
                  return (
                    <g key={`cam2-${idx}`} transform={`translate(${x}, ${y})`}>
                      <circle cx="0" cy="0" r="3" fill="#38bdf8" />
                      <line x1="0" y1="0" x2={-x * 0.18} y2={(-y - 60) * 0.18} stroke="#38bdf8" strokeWidth="1" opacity="0.6" />
                      <polygon
                        points="-4,-4 4,-4 6,4 -6,4"
                        fill="#0c4a6e"
                        stroke="#38bdf8"
                        strokeWidth="1"
                        transform={`rotate(${(Math.atan2(-y - 60, -x) * 180) / Math.PI + 90})`}
                      />
                    </g>
                  );
                })}
              </svg>
            </div>
          )}

          {/* Sparse Point Cloud COLMAP Overlay */}
          {pbrChannel === 'PointCloud' && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <svg className="w-80 h-[500px]" viewBox="0 0 280 500">
                {Array.from({ length: 160 }).map((_, i) => {
                  const cx = 140 + Math.sin(i * 13.7) * (30 + (i % 50));
                  const cy = 60 + (i * 2.6);
                  return (
                    <circle
                      key={`pt-${i}`}
                      cx={cx}
                      cy={cy}
                      r={Math.random() > 0.8 ? 2 : 1}
                      fill={i % 3 === 0 ? '#38bdf8' : i % 2 === 0 ? '#fbbf24' : '#34d399'}
                      opacity={0.85}
                    />
                  );
                })}
              </svg>
            </div>
          )}

          {/* Full Body Character Instance */}
          <FullBodyNpcAvatar
            assetId={selectedAsset}
            motionPreset={motionPreset}
            showSkeleton={showSkeleton}
            showWireframe={showWireframe}
            isPlaying={isPlaying}
            playbackSpeed={playbackSpeed}
            pbrChannel={pbrChannel}
          />

          {/* Transform Gizmo overlay on 3D Model */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <svg className="w-56 h-56" viewBox="-50 -50 100 100">
              {/* Translate Mode Gizmo */}
              {gizmoMode === 'translate' && (
                <g>
                  {/* X-Arrow Red */}
                  <line x1="0" y1="0" x2="38" y2="0" stroke="#ef4444" strokeWidth="2" />
                  <polygon points="38,-4 46,0 38,4" fill="#ef4444" />
                  {/* Y-Arrow Green */}
                  <line x1="0" y1="0" x2="-22" y2="28" stroke="#22c55e" strokeWidth="2" />
                  <polygon points="-20,25 -28,33 -26,23" fill="#22c55e" />
                  {/* Z-Arrow Blue */}
                  <line x1="0" y1="0" x2="0" y2="-38" stroke="#3b82f6" strokeWidth="2" />
                  <polygon points="-4,-38 0,-46 4,-38" fill="#3b82f6" />
                  <circle cx="0" cy="0" r="3" fill="#ffffff" />
                </g>
              )}

              {/* Rotate Mode Gizmo */}
              {gizmoMode === 'rotate' && (
                <g fill="none">
                  <circle cx="0" cy="0" r="36" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3,2" />
                  <ellipse cx="0" cy="0" rx="40" ry="18" stroke="#22c55e" strokeWidth="1.5" />
                  <ellipse cx="0" cy="0" rx="18" ry="40" stroke="#3b82f6" strokeWidth="1.5" />
                </g>
              )}

              {/* Scale Mode Gizmo */}
              {gizmoMode === 'scale' && (
                <g>
                  <line x1="0" y1="0" x2="34" y2="0" stroke="#ef4444" strokeWidth="2" />
                  <rect x="32" y="-3" width="6" height="6" fill="#ef4444" />
                  <line x1="0" y1="0" x2="-20" y2="24" stroke="#22c55e" strokeWidth="2" />
                  <rect x="-23" y="21" width="6" height="6" fill="#22c55e" />
                  <line x1="0" y1="0" x2="0" y2="-34" stroke="#3b82f6" strokeWidth="2" />
                  <rect x="-3" y="-37" width="6" height="6" fill="#3b82f6" />
                </g>
              )}
            </svg>
          </div>
        </div>

        {/* Reset Camera View Button & Orbit Hint */}
        <div className="absolute bottom-3 left-3 z-30 flex items-center space-x-2">
          <div className="font-mono text-[10px] text-zinc-400 bg-black/60 px-2.5 py-1 rounded border border-zinc-800/80 backdrop-blur-sm flex items-center space-x-1.5">
            <span className="text-sky-400">Left Click + Drag:</span>
            <span>Orbit Camera (Yaw: {Math.round(orbitAngle)}°)</span>
          </div>

          <button
            onClick={() => setOrbitAngle(0)}
            title="Reset Orbit Angle to Front"
            className="p-1 rounded bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        {/* Floating Bottom Right Telemetry */}
        <div className="absolute bottom-3 right-3 z-30 font-mono text-[11px] text-zinc-400 bg-black/60 px-2.5 py-1 rounded border border-zinc-800 backdrop-blur-sm flex items-center space-x-2">
          <span>Props in Scene: <span className="text-amber-400 font-semibold">{spawnedObjects.length}</span></span>
          <span className="text-zinc-600">|</span>
          <span className="text-sky-400 font-semibold">54 IK Bones</span>
        </div>
      </div>
    </div>
  );
};

