import React from 'react';

export type NpcMotionPreset = 'idle' | 'walk-in-place' | 'combat' | 'dialogue';
export type PbrChannelMode = 'Lit' | 'Albedo' | 'Normal' | 'ORM' | 'PointCloud';

interface FullBodyNpcAvatarProps {
  assetId: string;
  motionPreset: NpcMotionPreset;
  showSkeleton: boolean;
  showWireframe: boolean;
  isPlaying: boolean;
  playbackSpeed: number;
  pbrChannel?: PbrChannelMode;
}

export const FullBodyNpcAvatar: React.FC<FullBodyNpcAvatarProps> = ({
  assetId,
  motionPreset,
  showSkeleton,
  showWireframe,
  isPlaying,
  playbackSpeed,
  pbrChannel = 'Lit',
}) => {
  // Theme styling based on selected character asset and PBR channel mode
  const isCyborg = assetId.includes('Cyborg') || assetId.includes('android');
  const isCombat = assetId.includes('Songling') || assetId.includes('Combat');

  // Override colors if inspecting specific PBR maps
  const isNormalMode = pbrChannel === 'Normal';
  const isOrmMode = pbrChannel === 'ORM';
  const isAlbedoMode = pbrChannel === 'Albedo';
  const isPointCloud = pbrChannel === 'PointCloud';

  const primaryAccent = isNormalMode ? '#8080ff' : isOrmMode ? '#22c55e' : isCombat ? '#ef4444' : isCyborg ? '#06b6d4' : '#38bdf8';
  const secondaryAccent = isNormalMode ? '#ff8080' : isOrmMode ? '#eab308' : isCombat ? '#f97316' : isCyborg ? '#a855f7' : '#fbbf24';
  const suitBase1 = isNormalMode ? '#7a7aff' : isOrmMode ? '#1e3a1e' : isCombat ? '#2d1b1b' : isCyborg ? '#1e293b' : '#27272a';
  const suitBase2 = isNormalMode ? '#5e5eff' : isOrmMode ? '#142514' : isCombat ? '#180e0e' : isCyborg ? '#0f172a' : '#18181b';
  const armorPlate = isNormalMode ? '#8b8bff' : isOrmMode ? '#2e592e' : isCombat ? '#451a1a' : isCyborg ? '#334155' : '#3f3f46';

  // Motion animation classes
  const speedStyle = { animationDuration: `${(1 / playbackSpeed) * (motionPreset === 'walk-in-place' ? 1.4 : motionPreset === 'combat' ? 1.1 : 3.2)}s` };
  const headSpeedStyle = { animationDuration: `${(1 / playbackSpeed) * 4.0}s` };
  const legSpeedStyle = { animationDuration: `${(1 / playbackSpeed) * 1.4}s` };
  const armSpeedStyle = { animationDuration: `${(1 / playbackSpeed) * (motionPreset === 'walk-in-place' ? 1.4 : motionPreset === 'dialogue' ? 3.6 : 3.2)}s` };

  return (
    <div className="relative w-[320px] h-[520px] flex items-center justify-center select-none">
      {/* Ground Contact Shadow (Synchronized with in-place motion) */}
      <div
        className={`absolute bottom-4 w-52 h-10 rounded-[100%] bg-black/80 blur-md pointer-events-none transition-all duration-300 ${
          isPlaying && motionPreset === 'walk-in-place' ? 'anim-npc-shadow-step' : 'scale-100 opacity-70'
        }`}
      />

      {/* Hologram Contact Platform Projection Rings */}
      <div className="absolute bottom-2 w-64 h-16 rounded-[100%] border border-sky-500/25 pointer-events-none transform -rotate-x-60 flex items-center justify-center">
        <div
          className="w-48 h-12 rounded-[100%] border border-dashed border-sky-400/40 animate-spin"
          style={{ animationDuration: '24s' }}
        />
        <div className="w-28 h-7 rounded-[100%] border border-amber-400/30" />
      </div>

      {/* Main Articulated Full-Body SVG Model */}
      <svg
        className="w-full h-full relative z-10 overflow-visible"
        viewBox="0 0 280 500"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          {/* Material & Shading Gradients */}
          <linearGradient id="suitGradDynamic" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={suitBase1} />
            <stop offset="60%" stopColor={suitBase2} />
            <stop offset="100%" stopColor="#09090b" />
          </linearGradient>

          <linearGradient id="armorChestDynamic" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#71717a" />
            <stop offset="45%" stopColor={armorPlate} />
            <stop offset="100%" stopColor="#18181b" />
          </linearGradient>

          <linearGradient id="skinGradDynamic" x1="20%" y1="10%" x2="80%" y2="90%">
            <stop offset="0%" stopColor={isCyborg ? '#e2e8f0' : '#ffedd5'} />
            <stop offset="35%" stopColor={isCyborg ? '#cbd5e1' : '#fed7aa'} />
            <stop offset="70%" stopColor={isCyborg ? '#94a3b8' : '#fb923c'} />
            <stop offset="100%" stopColor={isCyborg ? '#64748b' : '#c2410c'} />
          </linearGradient>

          <linearGradient id="hairGradDynamic" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={isCombat ? '#7f1d1d' : isCyborg ? '#0284c7' : '#3f2212'} />
            <stop offset="60%" stopColor={isCombat ? '#450a0a' : isCyborg ? '#0369a1' : '#231207'} />
            <stop offset="100%" stopColor="#0c0a09" />
          </linearGradient>

          <linearGradient id="accentGradDynamic" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={secondaryAccent} />
            <stop offset="50%" stopColor={primaryAccent} />
            <stop offset="100%" stopColor={secondaryAccent} />
          </linearGradient>

          <linearGradient id="bootGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3f3f46" />
            <stop offset="70%" stopColor="#18181b" />
            <stop offset="100%" stopColor="#09090b" />
          </linearGradient>

          {/* Glow Filters */}
          <filter id="coreGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* ========================================================= */}
        {/* SKELETAL / KINEMATIC ROOT NODE */}
        {/* ========================================================= */}
        <g
          className={`${
            isPlaying
              ? motionPreset === 'walk-in-place'
                ? 'anim-npc-step-body'
                : motionPreset === 'combat'
                ? 'anim-npc-combat'
                : 'anim-npc-breathe'
              : ''
          }`}
          style={isPlaying ? speedStyle : {}}
        >
          {/* ------------------------------------------------------- */}
          {/* LOWER BODY: LEGS, THIGHS, KNEES, SHINS, AND BOOTS */}
          {/* ------------------------------------------------------- */}

          {/* LEFT LEG GROUP */}
          <g
            className={`${isPlaying && motionPreset === 'walk-in-place' ? 'anim-npc-step-leg-left' : ''}`}
            style={isPlaying ? legSpeedStyle : {}}
          >
            {/* Left Upper Thigh */}
            <path
              d="M 112 305 L 102 385 L 126 385 L 132 305 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            {/* Thigh Armor Plate & Tech Lines */}
            <path
              d="M 110 315 L 105 375 L 124 375 L 128 315 Z"
              fill={armorPlate}
              stroke="#52525b"
              strokeWidth="1"
            />
            <line x1="117" y1="318" x2="114" y2="370" stroke={primaryAccent} strokeWidth="1.5" />

            {/* Left Knee Joint Pivot */}
            <circle cx="114" cy="390" r="9" fill="#18181b" stroke="#71717a" strokeWidth="1.5" />
            <circle cx="114" cy="390" r="4" fill={primaryAccent} filter="url(#coreGlow)" />

            {/* Left Shin & Calf */}
            <path
              d="M 106 395 L 98 465 L 126 465 L 122 395 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            {/* Shin Guard Plate */}
            <polygon
              points="108,402 101,455 122,455 120,402"
              fill="#27272a"
              stroke="#52525b"
              strokeWidth="1"
            />
            <line x1="111" y1="406" x2="108" y2="450" stroke={secondaryAccent} strokeWidth="1.2" />

            {/* Left Combat Boot */}
            <path
              d="M 96 465 L 82 485 L 128 485 L 126 465 Z"
              fill="url(#bootGrad)"
              stroke="#52525b"
              strokeWidth="1.5"
            />
            {/* Boot Magnetic Sole */}
            <rect x="80" y="482" width="50" height="5" rx="1.5" fill="#18181b" stroke="#3f3f46" strokeWidth="1" />
            <line x1="86" y1="486" x2="124" y2="486" stroke={primaryAccent} strokeWidth="1" opacity="0.8" />
          </g>

          {/* RIGHT LEG GROUP */}
          <g
            className={`${isPlaying && motionPreset === 'walk-in-place' ? 'anim-npc-step-leg-right' : ''}`}
            style={isPlaying ? legSpeedStyle : {}}
          >
            {/* Right Upper Thigh */}
            <path
              d="M 148 305 L 154 385 L 178 385 L 168 305 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            {/* Right Thigh Armor Plate */}
            <path
              d="M 152 315 L 156 375 L 175 375 L 170 315 Z"
              fill={armorPlate}
              stroke="#52525b"
              strokeWidth="1"
            />
            <line x1="163" y1="318" x2="166" y2="370" stroke={primaryAccent} strokeWidth="1.5" />

            {/* Right Knee Joint Pivot */}
            <circle cx="166" cy="390" r="9" fill="#18181b" stroke="#71717a" strokeWidth="1.5" />
            <circle cx="166" cy="390" r="4" fill={primaryAccent} filter="url(#coreGlow)" />

            {/* Right Shin & Calf */}
            <path
              d="M 158 395 L 154 465 L 182 465 L 174 395 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            {/* Right Shin Guard Plate */}
            <polygon
              points="160,402 158,455 179,455 172,402"
              fill="#27272a"
              stroke="#52525b"
              strokeWidth="1"
            />
            <line x1="169" y1="406" x2="172" y2="450" stroke={secondaryAccent} strokeWidth="1.2" />

            {/* Right Combat Boot */}
            <path
              d="M 154 465 L 152 485 L 198 485 L 184 465 Z"
              fill="url(#bootGrad)"
              stroke="#52525b"
              strokeWidth="1.5"
            />
            {/* Boot Magnetic Sole */}
            <rect x="150" y="482" width="50" height="5" rx="1.5" fill="#18181b" stroke="#3f3f46" strokeWidth="1" />
            <line x1="156" y1="486" x2="194" y2="486" stroke={primaryAccent} strokeWidth="1" opacity="0.8" />
          </g>

          {/* ------------------------------------------------------- */}
          {/* PELVIS / HIPS & TACTICAL BELT */}
          {/* ------------------------------------------------------- */}
          <path
            d="M 104 285 L 98 315 L 140 328 L 182 315 L 176 285 Z"
            fill="#18181b"
            stroke="#52525b"
            strokeWidth="1.5"
          />
          {/* Tactical Belt & Buckle */}
          <rect x="96" y="280" width="88" height="12" rx="2" fill="#27272a" stroke="#71717a" strokeWidth="1" />
          <rect x="130" y="278" width="20" height="16" rx="2" fill="#3f3f46" stroke={primaryAccent} strokeWidth="1.5" />
          <circle cx="140" cy="286" r="3" fill={primaryAccent} />

          {/* Tactical Pouches */}
          <rect x="100" y="283" width="12" height="14" rx="1.5" fill="#18181b" stroke="#3f3f46" strokeWidth="0.8" />
          <rect x="168" y="283" width="12" height="14" rx="1.5" fill="#18181b" stroke="#3f3f46" strokeWidth="0.8" />

          {/* ------------------------------------------------------- */}
          {/* TORSO, CHEST ARMOR & CYBERNETIC CORE */}
          {/* ------------------------------------------------------- */}
          {/* Main Body Suit Base */}
          <path
            d="M 94 175 C 94 175, 84 210, 80 282 L 200 282 C 196 210, 186 175, 186 175 L 158 175 L 122 175 Z"
            fill="url(#suitGradDynamic)"
            stroke="#52525b"
            strokeWidth="1.5"
          />

          {/* Segmented Abdominal Armor Plates */}
          <path d="M 112 245 L 140 252 L 168 245 L 164 278 L 116 278 Z" fill="#27272a" stroke="#3f3f46" strokeWidth="1" />
          <path d="M 115 220 L 140 226 L 165 220 L 163 242 L 117 242 Z" fill="#27272a" stroke="#3f3f46" strokeWidth="1" />

          {/* Chest Rig / PBR Heavy Armor Plates */}
          <path
            d="M 98 180 L 140 215 L 182 180 L 186 220 C 186 240, 94 240, 94 220 Z"
            fill="url(#armorChestDynamic)"
            stroke="#71717a"
            strokeWidth="1.5"
          />

          {/* Glowing Arc Reactor / AI Neural Sync Core */}
          <circle cx="140" cy="202" r="14" fill="#0c0a09" stroke="#52525b" strokeWidth="1.5" />
          <circle cx="140" cy="202" r="10" fill="#18181b" stroke={primaryAccent} strokeWidth="1.5" />
          <circle
            cx="140"
            cy="202"
            r="6"
            fill={primaryAccent}
            filter="url(#coreGlow)"
            className="anim-npc-core"
          />
          {/* Core Radiating Power Conduits */}
          <line x1="140" y1="188" x2="140" y2="175" stroke={primaryAccent} strokeWidth="1.5" opacity="0.8" />
          <line x1="126" y1="202" x2="108" y2="195" stroke={secondaryAccent} strokeWidth="1.2" opacity="0.8" />
          <line x1="154" y1="202" x2="172" y2="195" stroke={secondaryAccent} strokeWidth="1.2" opacity="0.8" />
          <line x1="140" y1="216" x2="140" y2="248" stroke={primaryAccent} strokeWidth="1.5" opacity="0.8" />

          {/* ------------------------------------------------------- */}
          {/* ARMS, ELBOWS, GAUNTLETS, HANDS & FINGERS */}
          {/* ------------------------------------------------------- */}

          {/* LEFT ARM GROUP */}
          <g
            className={`${
              isPlaying
                ? motionPreset === 'walk-in-place'
                  ? 'anim-npc-step-arm-left'
                  : 'anim-npc-arm-left'
                : ''
            }`}
            style={isPlaying ? armSpeedStyle : {}}
          >
            {/* Left Shoulder Pauldron */}
            <path
              d="M 98 172 C 80 170, 68 184, 66 200 L 92 208 L 102 180 Z"
              fill={armorPlate}
              stroke="#71717a"
              strokeWidth="1.5"
            />
            <circle cx="82" cy="188" r="3" fill={secondaryAccent} />

            {/* Left Bicep / Upper Arm */}
            <path
              d="M 68 200 L 58 260 L 82 262 L 90 206 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            <line x1="72" y1="208" x2="68" y2="252" stroke={primaryAccent} strokeWidth="1.2" />

            {/* Left Elbow Joint */}
            <circle cx="70" cy="264" r="7" fill="#18181b" stroke="#71717a" strokeWidth="1.2" />
            <circle cx="70" cy="264" r="3" fill={primaryAccent} />

            {/* Left Forearm Gauntlet */}
            <path
              d="M 64 270 L 52 330 L 76 332 L 80 270 Z"
              fill="url(#armorChestDynamic)"
              stroke="#52525b"
              strokeWidth="1.2"
            />
            {/* Forearm Tech Screen / Status Bar */}
            <rect x="58" y="284" width="14" height="6" rx="1" fill="#0284c7" opacity="0.9" />

            {/* Left Wrist Joint */}
            <circle cx="64" cy="334" r="5" fill="#27272a" stroke="#71717a" strokeWidth="1" />

            {/* Left Hand & Articulated Fingers */}
            <path
              d="M 60 338 L 52 355 L 50 372 L 56 374 L 62 358 L 65 375 L 70 375 L 70 356 L 75 370 L 79 368 L 74 340 Z"
              fill="url(#skinGradDynamic)"
              stroke="#9a3412"
              strokeWidth="0.8"
            />
            {/* Cybernetic Palm Node */}
            <circle cx="64" cy="350" r="2.5" fill={primaryAccent} filter="url(#coreGlow)" />
          </g>

          {/* RIGHT ARM GROUP */}
          <g
            className={`${
              isPlaying
                ? motionPreset === 'walk-in-place'
                  ? 'anim-npc-step-arm-right'
                  : motionPreset === 'dialogue'
                  ? 'anim-npc-gesture-arm'
                  : 'anim-npc-arm-right'
                : ''
            }`}
            style={isPlaying ? armSpeedStyle : {}}
          >
            {/* Right Shoulder Pauldron */}
            <path
              d="M 182 172 C 200 170, 212 184, 214 200 L 188 208 L 178 180 Z"
              fill={armorPlate}
              stroke="#71717a"
              strokeWidth="1.5"
            />
            <circle cx="198" cy="188" r="3" fill={secondaryAccent} />

            {/* Right Bicep / Upper Arm */}
            <path
              d="M 212 200 L 222 260 L 198 262 L 190 206 Z"
              fill="url(#suitGradDynamic)"
              stroke="#3f3f46"
              strokeWidth="1.2"
            />
            <line x1="208" y1="208" x2="212" y2="252" stroke={primaryAccent} strokeWidth="1.2" />

            {/* Right Elbow Joint */}
            <circle cx="210" cy="264" r="7" fill="#18181b" stroke="#71717a" strokeWidth="1.2" />
            <circle cx="210" cy="264" r="3" fill={primaryAccent} />

            {/* Right Forearm Gauntlet */}
            <path
              d="M 216 270 L 228 330 L 204 332 L 200 270 Z"
              fill="url(#armorChestDynamic)"
              stroke="#52525b"
              strokeWidth="1.2"
            />
            {/* Holographic Wrist Emitter Node */}
            <rect x="208" y="284" width="14" height="6" rx="1" fill="#f59e0b" opacity="0.9" />

            {/* Right Wrist Joint */}
            <circle cx="216" cy="334" r="5" fill="#27272a" stroke="#71717a" strokeWidth="1" />

            {/* Right Hand & Articulated Fingers */}
            <path
              d="M 220 338 L 228 355 L 230 372 L 224 374 L 218 358 L 215 375 L 210 375 L 210 356 L 205 370 L 201 368 L 206 340 Z"
              fill="url(#skinGradDynamic)"
              stroke="#9a3412"
              strokeWidth="0.8"
            />
            {/* Cybernetic Palm Node */}
            <circle cx="216" cy="350" r="2.5" fill={primaryAccent} filter="url(#coreGlow)" />
          </g>

          {/* ------------------------------------------------------- */}
          {/* NECK, HEAD, FACE & CYBERNETIC DETAILS */}
          {/* ------------------------------------------------------- */}
          <g className={`${isPlaying ? 'anim-npc-head' : ''}`} style={isPlaying ? headSpeedStyle : {}}>
            {/* Neck & Tech Collar */}
            <path d="M 128 140 L 152 140 L 158 178 L 122 178 Z" fill="url(#skinGradDynamic)" />
            {/* Cybernetic Throat Collar Piece */}
            <path d="M 124 162 L 140 172 L 156 162 L 154 176 L 126 176 Z" fill="#18181b" stroke="#52525b" strokeWidth="1" />
            <circle cx="140" cy="168" r="2" fill={primaryAccent} />

            {/* Head Silhouette */}
            <path
              d="M 116 75 C 116 48, 164 48, 164 75 C 164 110, 154 142, 140 145 C 126 142, 116 110, 116 75 Z"
              fill="url(#skinGradDynamic)"
              stroke="#c2410c"
              strokeWidth="0.5"
            />

            {/* Cybernetic Ear Headset */}
            <rect x="110" y="86" width="6" height="14" rx="2" fill="#18181b" stroke="#71717a" strokeWidth="1" />
            <circle cx="113" cy="93" r="1.5" fill={primaryAccent} />
            <rect x="164" y="86" width="6" height="14" rx="2" fill="#18181b" stroke="#71717a" strokeWidth="1" />
            <circle cx="167" cy="93" r="1.5" fill={primaryAccent} />

            {/* Hair Style */}
            <path
              d="M 108 72 C 108 30, 172 30, 172 72 C 176 95, 172 122, 164 134 C 160 108, 164 78, 156 68 C 144 64, 132 64, 122 70 C 114 82, 118 106, 112 134 C 106 122, 104 95, 108 72 Z"
              fill="url(#hairGradDynamic)"
            />

            {/* Eyebrows */}
            <path d="M 124 84 Q 130 82 136 85" stroke="#3f2212" strokeWidth="1.6" fill="none" strokeLinecap="round" />
            <path d="M 144 85 Q 150 82 156 84" stroke="#3f2212" strokeWidth="1.6" fill="none" strokeLinecap="round" />

            {/* Eyes (With Realistic Blink Animation Cycle) */}
            <g className={`${isPlaying ? 'anim-npc-blink' : ''}`}>
              {/* Left Eye */}
              <ellipse cx="130" cy="90" rx="4.5" ry="2.5" fill="#ffffff" />
              <circle cx="130" cy="90" r="2.2" fill={primaryAccent} />
              <circle cx="130" cy="90" r="1" fill="#0f172a" />
              <circle cx="129.5" cy="89.3" r="0.7" fill="#ffffff" />

              {/* Right Eye */}
              <ellipse cx="150" cy="90" rx="4.5" ry="2.5" fill="#ffffff" />
              <circle cx="150" cy="90" r="2.2" fill={primaryAccent} />
              <circle cx="150" cy="90" r="1" fill="#0f172a" />
              <circle cx="149.5" cy="89.3" r="0.7" fill="#ffffff" />
            </g>

            {/* Nose */}
            <path d="M 140 88 L 138 104 L 142 104" stroke="#9a3412" strokeWidth="1" fill="none" />

            {/* Lips (Animated talking when dialogue preset active) */}
            <path
              d={
                motionPreset === 'dialogue' && isPlaying
                  ? 'M 134 116 Q 140 123 146 116'
                  : 'M 133 117 Q 140 121 147 117'
              }
              stroke="#be123c"
              strokeWidth="1.8"
              fill="none"
              strokeLinecap="round"
            />
          </g>

          {/* ========================================================= */}
          {/* DEBUG SKELETAL RIG BONES & IK JOINTS (When Toggled) */}
          {/* ========================================================= */}
          {showSkeleton && (
            <g stroke="#22c55e" strokeWidth="1.8" fill="#ffffff" opacity="0.9" strokeLinecap="round">
              {/* Spine */}
              <line x1="140" y1="145" x2="140" y2="202" />
              <line x1="140" y1="202" x2="140" y2="286" />

              {/* Clavicles & Arms */}
              <line x1="140" y1="175" x2="82" y2="188" />
              <line x1="82" y1="188" x2="70" y2="264" />
              <line x1="70" y1="264" x2="64" y2="334" />
              <line x1="64" y1="334" x2="64" y2="365" />

              <line x1="140" y1="175" x2="198" y2="188" />
              <line x1="198" y1="188" x2="210" y2="264" />
              <line x1="210" y1="264" x2="216" y2="334" />
              <line x1="216" y1="334" x2="216" y2="365" />

              {/* Pelvis & Legs */}
              <line x1="140" y1="286" x2="114" y2="315" />
              <line x1="114" y1="315" x2="114" y2="390" />
              <line x1="114" y1="390" x2="114" y2="465" />
              <line x1="114" y1="465" x2="105" y2="485" />

              <line x1="140" y1="286" x2="166" y2="315" />
              <line x1="166" y1="315" x2="166" y2="390" />
              <line x1="166" y1="390" x2="166" y2="465" />
              <line x1="166" y1="465" x2="175" y2="485" />

              {/* Joint Dots */}
              <circle cx="140" cy="145" r="4" fill="#22c55e" stroke="#ffffff" strokeWidth="1" />
              <circle cx="140" cy="202" r="4" fill="#22c55e" stroke="#ffffff" strokeWidth="1" />
              <circle cx="140" cy="286" r="4" fill="#22c55e" stroke="#ffffff" strokeWidth="1" />
              <circle cx="82" cy="188" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="70" cy="264" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="64" cy="334" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="198" cy="188" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="210" cy="264" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="216" cy="334" r="3.5" fill="#eab308" stroke="#ffffff" strokeWidth="1" />
              <circle cx="114" cy="390" r="3.5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1" />
              <circle cx="114" cy="465" r="3.5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1" />
              <circle cx="166" cy="390" r="3.5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1" />
              <circle cx="166" cy="465" r="3.5" fill="#3b82f6" stroke="#ffffff" strokeWidth="1" />
            </g>
          )}

          {/* ========================================================= */}
          {/* WIREFRAME MESH OVERLAY (When Toggled) */}
          {/* ========================================================= */}
          {showWireframe && (
            <g stroke="#38bdf8" strokeWidth="0.5" opacity="0.65" fill="none">
              {/* Torso & Head Wireframe Traces */}
              <polygon points="130,90 140,104 150,90" />
              <polygon points="130,90 140,75 150,90" />
              <polygon points="122,178 140,215 158,178" />
              <polygon points="98,180 140,215 182,180" />
              <polygon points="94,220 140,252 186,220" />
              <polygon points="104,285 140,328 176,285" />

              {/* Legs Wireframe Traces */}
              <polygon points="112,305 102,385 126,385" />
              <polygon points="148,305 154,385 178,385" />
              <polygon points="106,395 98,465 126,465" />
              <polygon points="158,395 154,465 182,465" />

              {/* Arms Wireframe Traces */}
              <polygon points="98,172 68,200 90,206" />
              <polygon points="182,172 212,200 190,206" />
              <polygon points="68,200 58,260 82,262" />
              <polygon points="212,200 222,260 198,262" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};
