import React from 'react';
import {
  FolderTree,
  Terminal,
  Activity,
  Cpu,
  Wifi,
  GitBranch,
  CheckCircle2,
  Sliders,
  PanelLeft,
  Box,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';

interface FooterStatusBarProps {
  isPlaying: boolean;
  totalLogs: number;
  isDrawerOpen?: boolean;
  onToggleDrawer?: () => void;
  isQuickAssetsDrawerOpen?: boolean;
  onToggleQuickAssetsDrawer?: () => void;
  placedPropsCount?: number;
  isDebugConsoleOpen?: boolean;
  onToggleDebugConsole?: () => void;
}

export const FooterStatusBar: React.FC<FooterStatusBarProps> = ({
  isPlaying,
  totalLogs,
  isDrawerOpen = true,
  onToggleDrawer,
  isQuickAssetsDrawerOpen = false,
  onToggleQuickAssetsDrawer,
  placedPropsCount = 0,
  isDebugConsoleOpen = false,
  onToggleDebugConsole,
}) => {
  return (
    <div className="h-6.5 bg-[#101014] border-t border-[#27272a] px-2 flex items-center justify-between text-[11px] font-mono text-zinc-400 select-none z-50 shrink-0">
      {/* Left Quick Dock Tabs */}
      <div className="flex items-center space-x-1.5">
        {/* Quick Props / Assets Drawer Toggle Button */}
        <button
          onClick={onToggleQuickAssetsDrawer}
          className={`flex items-center space-x-1 px-2 py-0.5 rounded transition-all ${
            isQuickAssetsDrawerOpen
              ? 'bg-amber-950 text-amber-200 border border-amber-500/50 font-bold shadow-xs'
              : 'hover:bg-zinc-800 text-zinc-300 bg-zinc-900/60 border border-zinc-800/80'
          }`}
          title="Toggle Bottom Quick Props & Assets Drawer [Alt+A]"
        >
          <Box className={`w-3 h-3 ${isQuickAssetsDrawerOpen ? 'text-amber-400' : 'text-amber-500'}`} />
          <span>Quick Props</span>
          {isQuickAssetsDrawerOpen ? (
            <ChevronDown className="w-3 h-3 text-amber-400" />
          ) : (
            <ChevronUp className="w-3 h-3 text-zinc-400" />
          )}
          {placedPropsCount > 0 && (
            <span className="ml-0.5 px-1 py-0.2 rounded-full bg-amber-500 text-black text-[9px] font-bold font-mono">
              {placedPropsCount}
            </span>
          )}
        </button>

        {/* Output Log / Debug Console Drawer Toggle Button */}
        <button
          onClick={onToggleDebugConsole}
          className={`flex items-center space-x-1 px-2 py-0.5 rounded transition-all ${
            isDebugConsoleOpen
              ? 'bg-emerald-950 text-emerald-200 border border-emerald-500/50 font-bold shadow-xs'
              : 'hover:bg-zinc-800 text-zinc-300 bg-zinc-900/60 border border-zinc-800/80'
          }`}
          title="Toggle Debug Console Drawer [Ctrl+`]"
        >
          <Terminal className={`w-3 h-3 ${isDebugConsoleOpen ? 'text-emerald-300' : 'text-emerald-400'}`} />
          <span>Output Log ({totalLogs})</span>
          {isDebugConsoleOpen ? (
            <ChevronDown className="w-3 h-3 text-emerald-400" />
          ) : (
            <ChevronUp className="w-3 h-3 text-zinc-400" />
          )}
        </button>

        <div className="h-3 w-[1px] bg-zinc-800" />

        {/* Legacy & Git Branch tag */}
        <div className="hidden lg:flex items-center space-x-1 text-zinc-500">
          <GitBranch className="w-3 h-3 text-zinc-400" />
          <span>legacy / main [clean]</span>
        </div>
      </div>

      {/* Center Hardware Telemetry */}
      <div className="hidden md:flex items-center space-x-3 text-zinc-400">
        <div className="flex items-center space-x-1">
          <Cpu className="w-3 h-3 text-sky-400" />
          <span>RAM: 2.1 GB / 16 GB</span>
        </div>
        <span className="text-zinc-700">|</span>
        <div className="flex items-center space-x-1">
          <Activity className="w-3 h-3 text-purple-400" />
          <span>VRAM: 3.4 GB / 8 GB</span>
        </div>
        <span className="text-zinc-700">|</span>
        <span className="text-zinc-400">Engine: UE 5.5 AI-Sim</span>
      </div>

      {/* Right Connection Stats */}
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-1.5 px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800">
          <span
            className={`w-2 h-2 rounded-full ${
              isPlaying ? 'bg-emerald-400 shadow-[0_0_6px_#34d399] animate-pulse' : 'bg-emerald-500'
            }`}
          />
          <span className="text-zinc-300">WebRTC:</span>
          <span className="text-emerald-400 font-semibold">Connected</span>
          <span className="text-zinc-600">|</span>
          <span className="text-zinc-400">Latency:</span>
          <span className="text-emerald-400 font-semibold">{isPlaying ? '42ms' : '45ms'}</span>
        </div>
      </div>
    </div>
  );
};

